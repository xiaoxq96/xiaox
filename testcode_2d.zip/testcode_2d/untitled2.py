# -*- coding: utf-8 -*-
"""
Created on Sun Oct 23 04:14:03 2022

@author: Xiaox
"""
import argparse
from itertools import combinations, permutations
import numpy as np
from typing import Tuple
import re
import matplotlib.pyplot as plt
import matplotlib.patches as mpatch


from unilts import read_instance


class zweiD_Problem():
    def __init__(self,data = read_instance()):
        self.stueck_ids = np.repeat(data["stueck_ids"], data["quantity"])
        self.num_stueck = np.sum(data["quantity"], dtype=np.int32)
        self.stueck_lange = np.repeat(data["stueck_lange"], data["quantity"])
        self.stueck_breite = np.repeat(data["stueck_breite"], data["quantity"])
        print(f'Anzahl der Stücke: {self.num_stueck}')
        self.platte_lange = data["platte_dim"][0]
        self.platte_breite = data["platte_dim"][1]
        self.num_platte = data["num_platte"]
        self.gesamte_platte_lange=self.platte_lange*self.num_platte
        self.lowest_num_platte = np.ceil(
            np.sum(self.stueck_lange*self.stueck_breite) / (
                    self.platte_lange*self.platte_breite))
        if self.lowest_num_platte > self.num_platte:
            raise RuntimeError(
                f'anzahl der Platten ist im mindesten {self.lowest_num_platte}'+
                    'try increasing the number of platte'
            )
        print(f'anzahl der Platten ist im mindesten:{self.lowest_num_platte}')
        
        
        
        self.X_i={}
        
    def effective_dim(self):
        self.eff_dim={}
        for i in range(self.num_stueck):
            self.eff_dim[i]={}
            p1=list(permutations([self.stueck_lange[(i)],self.stueck_breite[(i)]]))
            self.eff_dim[i][0]=p1[(0)]
            self.eff_dim[i][1]=p1[(1)]
        return [self.eff_dim]
    
    
    def define_variables(self):
        #self.P_j={(j):'s_{}'.format(j)for j in range(self.num_platte)}
        self.X_i={(i,j,r,a,b):'x_{}_{}_{}_{}_{}'.format(i,j,r,a,b)for i in range(self.num_stueck)
                   for j in range(self.num_platte)
                   for r in range(2) #0:nicht umgedrehnt 1:umgedrehnt
                   for a in range(j*self.platte_lange,(j+1)*self.platte_lange-self.eff_dim[i][r][0]+1)
                   for b in range(self.platte_breite - self.eff_dim[i][r][1]+1)}
        self.variables=[self.X_i]
        return self.variables
    
    def z(self):
        xx=[]
        for i in range(self.num_stueck):
            for r in range(2): #0:nicht umgedrehnt 1:umgedrehnt
                for a in range(1*self.platte_lange,(2)*self.platte_lange-self.eff_dim[i][r][0]+1):
                    for b in range(self.platte_breite - self.eff_dim[i][r][1]+1):
                        xx.append(self.X_i[(i,1,r,a,b)])
        print(len(xx))
          
            
if __name__== "__main__":
    a=zweiD_Problem()
    a.effective_dim()
    v=a.define_variables()
    a.z()