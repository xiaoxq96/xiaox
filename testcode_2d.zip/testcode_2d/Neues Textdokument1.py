import matplotlib.pyplot as plt
import matplotlib.patches as mpatch


fig = plt.figure()
ax = fig.add_subplot()

#for j in range(2):
plt.axvline(x=20, ymax = 0.5)

plt.axhline(y=10,xmax=0.5)
ax.axis([0,2*40,0,2*10])
ax.set_aspect(1)
plt.show()