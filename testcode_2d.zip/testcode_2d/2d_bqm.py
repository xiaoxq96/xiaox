# -*- coding: utf-8 -*-
"""
Created on Wed Aug 31 15:55:56 2022

@author: Xiaox
"""

import argparse
from dimod import quicksum, BinaryQuadraticModel, Real, Binary, SampleSet
from dwave.system import LeapHybridBQMSampler
from hybrid.reference.kerberos import KerberosSampler
from itertools import combinations, permutations
import numpy as np
from typing import Tuple
from fractions import Fraction
import re
import matplotlib.pyplot as plt
import matplotlib.patches as mpatch
from dwave.system.samplers import DWaveSampler


from unilts import read_instance


class zweiD_Problem():
    def __init__(self,data = read_instance()):
        self.stueck_ids = np.repeat(data["stueck_ids"], data["quantity"])
        self.num_stueck = np.sum(data["quantity"], dtype=np.int32)
        self.stueck_lange = np.repeat(data["stueck_lange"], data["quantity"])
        self.stueck_breite = np.repeat(data["stueck_breite"], data["quantity"])
        print(f'Anzahl der Stücke: {self.num_stueck}')
        self.platte_lange = data["platte_dim"][0]
        self.platte_breite = data["platte_dim"][1]
        self.num_platte = data["num_platte"]
        self.gesamte_platte_lange=self.platte_lange*self.num_platte
        self.lowest_num_platte = np.ceil(
            np.sum(self.stueck_lange*self.stueck_breite) / (
                    self.platte_lange*self.platte_breite))
        if self.lowest_num_platte > self.num_platte:
            raise RuntimeError(
                f'anzahl der Platten ist im mindesten {self.lowest_num_platte}'+
                    'try increasing the number of platte'
            )
        print(f'anzahl der Platten ist im mindesten:{self.lowest_num_platte}')
        
        
        self.P_j={}
        self.X_ira={}
        self.Y_irb={}
        
    
    def define_variables(self):
        self.P_j={(j):'p_{}'.format(j)for j in range(self.num_platte)}
        self.X_ira={(i,r,a):'x_{}_{}_{}'.format(i,r,a)for i in range(self.num_stueck)
                   for r in range(2) #0:nicht umgedrehnt 1:umgedrehnt
                   for a in range(self.gesamte_platte_lange)}
        self.Y_irb={(i,r,b):'y_{}_{}_{}'.format(i,r,b)for i in range(self.num_stueck)
                   for r in range(2) #0:nicht umgedrehnt 1:umgedrehnt
                   for b in range(self.platte_breite)}
        self.variables=[self.X_ira,self.Y_irb]
        return self.variables
    
    def define_bqm(self):
        """define bqm model
        For the bqm model, the variables should be added to the bqm model by the command "bqm.add_variable" """
        self.bqm=BinaryQuadraticModel('BINARY')
        for i in self.variables:      
            for j in i.values():
                self.bqm.add_variable(j)
        return self.bqm
    
    def variables_constraints(self,weight):
        for i in range(self.num_stueck):
            self.bqm.add_linear_equality_constraint([(self.X_ira[(i,r,a)],1)for a in range(self.gesamte_platte_lange)
                                                     for r in range(2)],
                                                            lagrange_multiplier=weight, 
                                                            constant=-1)
            
            self.bqm.add_linear_equality_constraint([(self.Y_irb[(i,r,b)],1)for b in range(self.platte_breite)
                                                    for r in range(2)],
                                                            lagrange_multiplier=weight, 
                                                            constant=-1)
            '''
            self.bqm.add_linear_equality_constraint([(self.R_ir[(i,r)],1)for r in range(2)],
                                                            lagrange_multiplier=weight, 
                                                            constant=-1)
            '''
        return
    
   
    def stuecke_position_constraint(self,weight):
     #stück_i只能在已经启用的stang_j上切割
        for i in range(self.num_stueck):
            for a in range(self.gesamte_platte_lange):
                for r in range(2):
                        for j in range(self.num_platte):
                            if j == int(a/self.platte_lange):
                                self.bqm.add_quadratic(self.P_j[(j)],self.X_ira[(i,r,a)],weight)
                    
                    
    
    def effective_dim(self):
        self.eff_dim={}
        for i in range(self.num_stueck):
            self.eff_dim[i]={}
            p1=list(permutations([self.stueck_lange[(i)],self.stueck_breite[(i)]]))
            self.eff_dim[i][0]=p1[(0)]
            self.eff_dim[i][1]=p1[(1)]
        return [self.eff_dim]
        '''
        self.el={}
        self.eb={}
        for i in range(self.num_stueck):
            self.el[(i)]=[(self.R_ir[(i,0)], -(a+self.stueck_lange[i]))for a in range(self.gesamte_stange_lange+1)]
            self.eb[(i)]=(self.stueck_breite[i]* self.R_i[(i)])+(self.stueck_lange[i]*(1-self.R_i[(i)]))
        return [self.el,self.eb]
        '''

    def nenner(self):
        self.x_nenner={}
        self.y_nenner={}
        for i, k in combinations(range(self.num_stueck),r=2):
            for r in range(2):
                for s in range(2):
                    self.x_nenner[(i,k,r,s)]=(2*self.eff_dim[i][r][1]+self.eff_dim[k][s][1]-2)/2*(self.eff_dim[k][s][1]-1)+(
                        2*self.eff_dim[k][s][1]+self.eff_dim[i][r][1]-2)/2*(self.eff_dim[i][r][1]-1)+(
                            self.platte_breite-self.eff_dim[i][r][1]-self.eff_dim[k][s][1]+2)*(self.eff_dim[i][r][1]+self.eff_dim[k][s][1]-1)
                    self.y_nenner[(i,k,r,s)]=(2*self.eff_dim[i][r][0]+self.eff_dim[k][s][0]-2)/2*(self.eff_dim[k][s][0]-1)+(
                        2*self.eff_dim[k][s][0]+self.eff_dim[i][r][0]-2)/2*(self.eff_dim[i][r][0]-1)+(
                            self.gesamte_platte_lange-self.eff_dim[i][r][0]-self.eff_dim[k][s][0]+2)*(self.eff_dim[i][r][0]+self.eff_dim[k][s][0]-1)
        return(self.x_nenner,self.y_nenner)



    def umdrehnung(self,weight):
        for i in range(self.num_stueck):
            for r in range(2):
                for s in range(2):
                    for a in range(self.gesamte_platte_lange):
                        for b in range(self.platte_breite):
                            #self.bqm.add_linear(self.Y_irb[(i,r,b)])
                            if r != s:
                                self.bqm.add_quadratic(self.X_ira[(i,r,a)],self.Y_irb[(i,s,b)],weight)
        return


    def geomerie_constraint(self,weight):
        '''
        for i, k in combinations(range(self.num_stueck),r=2):
            for r in range(2):
                for s in range(2):
                    cc=[(self.X_ira[(k,s,c)], 1)for c in range(self.gesamte_platte_lange)]
                    aa=[(self.X_ira[(i,r,a)], -1)for a in range(self.gesamte_platte_lange)]
                    self.bqm.add_linear_inequality_constraint(cc+aa,
                                                              lagrange_multiplier=weight,
                                                              constant=self.gesamte_stange_lange,
                                                              lb=(-self.eff_dim[k][s][0]),
                                                              up=(self.eff_dim[i][r][0])
        '''

        
        for i, k in combinations(range(self.num_stueck),r=2):
            for r in range(2):
                for s in range(2):
                    for a in range(self.gesamte_platte_lange):
                        for c in range(self.gesamte_platte_lange):
                            if ((a-self.eff_dim[k][s][0]) < c < (a+self.eff_dim[i][r][0])):
                                for b in range(self.platte_breite):
                                    for d in range(self.platte_breite):
                                        if ((b-self.eff_dim[k][s][1])< d < (b+self.eff_dim[i][r][1])):
                                            self.bqm.add_quadratic(self.Y_irb[(i,r,b)],self.Y_irb[(k,s,d)],weight/self.y_nenner[(i,k,r,s)])
                                            self.bqm.add_quadratic(self.X_ira[(i,r,a)],self.X_ira[(k,s,c)],weight/self.x_nenner[(i,k,r,s)])
        
                                
                                    '''
                                    if ((a-self.eff_dim[k][s][0]) < c < (a+self.eff_dim[i][r][0])) and ((b-self.eff_dim[k][s][1])< d < (b+self.eff_dim[i][r][1])):
                                        self.bqm.add_quadratic(self.Y_irb[(i,r,b)],self.Y_irb[(k,s,d)],weight)
                                    '''
        return
    
    def grenze_constraint(self,weight):
        for i in range(self.num_stueck):
            for r in range(2):
                for a in range(self.gesamte_platte_lange):
                        for j in range(self.num_platte):
                           
                
                       
                        #if j!= int(a/30):
                            #self.bqm.add_quadratic(self.X_ia[(i,a)],self.U_ij[(i,j)],weight)
                            
                        
                            if j == int(a/self.platte_lange)and(a+self.eff_dim[i][r][0])>((j+1)*self.platte_lange):
                                    self.bqm.add_linear(self.X_ira[(i,r,a)],weight)
                for b in range(self.platte_breite):
                    if (b+self.eff_dim[i][r][1])>(self.platte_breite):
                        self.bqm.add_linear(self.Y_irb[(i,r,b)],weight)
        return
    
    def anzahl_objective(self,weight):
        for j in range(self.num_platte):
            self.bqm.add_linear(self.P_j[(j)],-weight)
        return
    
    def reste_objektive(self,weight):
        for j in range(self.num_platte):
            self.bqm.add_linear(self.P_j[(j)],self.platte_lange*self.platte_breite*weight)
            for i in range(self.num_stueck):
                self.bqm.add_linear(self.U_ij[(i,j)],-(self.stueck_lange[i]*self.stueck_breite[i]*weight))
        return
    
    def call_bqm_solver(self):
        sampler = KerberosSampler().sample(self.bqm,max_iter=3,convergence=3,qpu_sampler=DWaveSampler(),qpu_params={'label': 'stange_bqm'},qpu_reads=1000)
        samplerSET=sampler.samples()
        self.solution={}
        for key in samplerSET:
            sampler =key
        for key in sampler:
            if sampler[key] !=0 and "slack" not in key:
                self.solution[key]=sampler[key]
        return self.solution
    
    def zeichnung(self):
        self.eff_x_daten=list(key for key in self.solution.keys() if key in self.X_ira.values())
        self.eff_y_daten=list(key for key in self.solution.keys() if key in self.Y_irb.values())
        print(self.eff_x_daten,self.eff_y_daten)
        self.ids=[]
        self.um=[]
        self.x_achse=[]
        self.y_achse=[]
        for n in self.eff_x_daten:
            for q in self.eff_y_daten:
                x_zahlen=re.findall(r"\d+",n)
                ids_x_pos= list(map(int,x_zahlen))
                y_zahlen=re.findall(r"\d+",q)
                ids_y_pos= list(map(int,y_zahlen))
                if ids_x_pos[0] == ids_y_pos[0]:
                    if ids_x_pos[1] == ids_y_pos[1]:
                        self.ids.append(ids_x_pos[(0)])
                        self.um.append(ids_x_pos[(1)])
                        self.x_achse.append(ids_x_pos[(2)])
                        self.y_achse.append(ids_y_pos[(2)])
        print(self.ids)
        print(self.um)
        print(self.x_achse)
        print(self.y_achse)


        fig = plt.figure()
        ax = fig.add_subplot()
        n=self.num_stueck
        colors=plt.cm.jet(np.linspace(0, 1, n))
        for x,y,i,r,c in zip(self.x_achse,self.y_achse,self.ids,self.um,colors):
                txt=str(i)
                plt.text(x+0.5,y+0.5,txt,fontsize=7)
                rect=mpatch.Rectangle((x,y),self.eff_dim[i][r][0],self.eff_dim[i][r][1],edgecolor = 'green',facecolor = c,fill=True,alpha=0.3)
                ax.add_patch(rect)
        
        ticks=[]
        labels=[]
        for j in range(self.num_platte):
            ticks.append((j+1)*self.platte_lange)
            labels.append('Platte_' + str(j+1))
        plt.xticks(ticks,labels)
        ax.axis([0,2*self.gesamte_platte_lange,0,2*self.platte_breite])
        plt.show()
        

    def prufung(self):
        #print(self.bqm.get_quadratic(self.X_ira[(3,0,5)],self.Y_irb[(3,1,7)]))
        #for i in range(1):
            #for a in range(self.gesamte_platte_lange):
            #for b in range(self.platte_breite):
                    #@print(self.bqm.get_linear(self.Y_irb[(i,0,b)]))
                #for b in range(self.platte_breite):

    
                for a in range(self.gesamte_platte_lange):
                    for b in range(self.platte_breite):
                        for d in range(self.platte_breite):
                            for c in range(self.gesamte_platte_lange):
                                if a==18 and b==18 and c==19 and d == 19:
                                    print(self.bqm.get_quadratic(self.Y_irb[(3,0,b)],self.Y_irb[(6,1,d)]))
                                    print(self.bqm.get_quadratic(self.X_ira[(3,0,a)],self.X_ira[(6,1,c)]))
    
                                  

        
if __name__== "__main__":
    a=zweiD_Problem()
    v=a.define_variables()
    bqm=a.define_bqm()
    a.effective_dim()
    a.nenner()
    a.umdrehnung(1150)
    a.variables_constraints(1200)
    
    a.geomerie_constraint(250)
    a.grenze_constraint(250)
    
    #a.anzahl_objective(200)
    #a.stuecke_position_constraint(1250)
    
    #a.reste_objektive(200)
    
    #a.prufung()
    
    
    solution= a.call_bqm_solver()
    print(solution)
    a.zeichnung()       
    
            