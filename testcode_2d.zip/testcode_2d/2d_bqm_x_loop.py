# -*- coding: utf-8 -*-
"""
Created on Wed Aug 31 15:55:56 2022

@author: Xiaox
"""


from dimod import quicksum, BinaryQuadraticModel, Real, Binary, SampleSet
from dwave.system import LeapHybridBQMSampler
from dwave.system import EmbeddingComposite, DWaveSampler
import hybrid
#from ker import KerberosSampler
from hybrid.reference.kerberos import KerberosSampler
from hybrid.decomposers import EnergyImpactDecomposer


import argparse
from itertools import combinations, permutations
import numpy as np
from typing import Tuple
import re
import matplotlib.pyplot as plt
import matplotlib.patches as mpatch


from unilts import read_instance


class zweiD_Problem():
    def __init__(self,data = read_instance()):
        self.stueck_ids = np.repeat(data["stueck_ids"], data["quantity"])
        self.num_stueck = np.sum(data["quantity"], dtype=np.int32)
        self.stueck_lange = np.repeat(data["stueck_lange"], data["quantity"])
        self.stueck_breite = np.repeat(data["stueck_breite"], data["quantity"])
        print(f'Anzahl der Stücke: {self.num_stueck}')
        self.platte_lange = data["platte_dim"][0]
        self.platte_breite = data["platte_dim"][1]
        self.num_platte = data["num_platte"]
        self.gesamte_platte_lange=self.platte_lange*self.num_platte
        self.lowest_num_platte = np.ceil(
            np.sum(self.stueck_lange*self.stueck_breite) / (
                    self.platte_lange*self.platte_breite))
        self.lowest_flaeche=self.lowest_num_platte*self.platte_lange*self.platte_breite
        self.gesamte_flaeche=self.gesamte_platte_lange*self.platte_breite
        if self.lowest_num_platte > self.num_platte:
            raise RuntimeError(
                f'anzahl der Platten ist im mindesten {self.lowest_num_platte}'+
                    'try increasing the number of platte'
            )
        print(f'anzahl der Platten ist im mindesten:{self.lowest_num_platte}')
        
        
        
        self.X_i={}
        
    
    def define_variables(self):
        #self.P_j={(j):'s_{}'.format(j)for j in range(self.num_platte)}
        self.X_i={(i,j,r,a,b):'x_{}_{}_{}_{}_{}'.format(i,j,r,a,b)for i in range(self.num_stueck)
                   for j in range(self.num_platte)
                   for r in range(2) #0:nicht umgedrehnt 1:umgedrehnt
                   for a in range(j*self.platte_lange,(j+1)*self.platte_lange-self.eff_dim[i][r][0]+1)
                   for b in range(self.platte_breite - self.eff_dim[i][r][1]+1)}
        self.variables=[self.X_i]
        return self.variables
    
    def define_bqm(self):
        """define bqm model
        For the bqm model, the variables should be added to the bqm model by the command "bqm.add_variable" """
        self.bqm=BinaryQuadraticModel('BINARY')
        for i in self.variables:      
            for j in i.values():
                self.bqm.add_variable(j)
        return self.bqm
    
    def variables_constraints(self,weight):
        for i in range(self.num_stueck):
            self.bqm.add_linear_equality_constraint([(self.X_i[(i,j,r,a,b)],1)for j in range(self.num_platte)
                                                     for r in range(2) #0:nicht umgedrehnt 1:umgedrehnt
                                                     for a in range(j*self.platte_lange,(j+1)*self.platte_lange-self.eff_dim[i][r][0]+1)
                                                     for b in range(self.platte_breite - self.eff_dim[i][r][1]+1)],
                                                            lagrange_multiplier=self.gesamte_flaeche*weight,
                                                            constant=-1)
            '''
            self.bqm.add_linear_equality_constraint([(self.Y_ia[(i,b)],1)for b in range(self.platte_breite)],
                                                            lagrange_multiplier=weight, 
                                                            constant=-1)
            self.bqm.add_linear_equality_constraint([(self.R_ir[(i,r)],1)for r in range(2)],
                                                            lagrange_multiplier=weight, 
                                                            constant=-1)
            '''
        return
    
   
    def stuecke_position_constraint(self,weight):
     #stück_i只能在已经启用的stang_j上切割
         for i in range(self.num_stueck):
            for a in range(self.gesamte_platte_lange):
                for r in range(2):
                    for b in range(self.platte_breite):
                        for j in range(self.num_platte):
                            if j == int(a/self.platte_lange):
                                self.bqm.add_quadratic(self.P_j[(j)],self.X_i[(i,r,a,b)],weight)
                    
                    
    
    def effective_dim(self):
        self.eff_dim={}
        for i in range(self.num_stueck):
            self.eff_dim[i]={}
            p1=list(permutations([self.stueck_lange[(i)],self.stueck_breite[(i)]]))
            self.eff_dim[i][0]=p1[(0)]
            self.eff_dim[i][1]=p1[(1)]
        return [self.eff_dim]
        '''
        self.el={}
        self.eb={}
        for i in range(self.num_stueck):
            self.el[(i)]=[(self.R_ir[(i,0)], -(a+self.stueck_lange[i]))for a in range(self.gesamte_stange_lange+1)]
            self.eb[(i)]=(self.stueck_breite[i]* self.R_i[(i)])+(self.stueck_lange[i]*(1-self.R_i[(i)]))
        return [self.el,self.eb]
        '''
    def geomerie_constraint(self,weight):
        for i, k in combinations(range(self.num_stueck),r=2):
            for j in range(self.num_platte):
                for r in range(2):
                    for s in range(2):
                        for a in range(j*self.platte_lange,(j+1)*self.platte_lange-self.eff_dim[i][r][0]+1):
                            for c in range(j*self.platte_lange,(j+1)*self.platte_lange-self.eff_dim[k][s][0]+1):
                                if ((a-self.eff_dim[k][s][0]) < c < (a+self.eff_dim[i][r][0])):
                                    for b in range(self.platte_breite - self.eff_dim[i][r][1]+1):
                                        for d in range(self.platte_breite - self.eff_dim[k][s][1]+1):
                                            if ((b-self.eff_dim[k][s][1])< d < (b+self.eff_dim[i][r][1])):
                            #for c in range(a-self.eff_dim[k][s][0]+1,a+self.eff_dim[i][r][0]):
                                #for d in range(b-self.eff_dim[k][s][1]+1,b+self.eff_dim[i][r][1]):
                                    #if ((a-self.eff_dim[k][s][0]) < c < (a+self.eff_dim[i][r][0])) and ((b-self.eff_dim[k][s][1])< d < (b+self.eff_dim[i][r][1])):
                                                self.bqm.add_quadratic(self.X_i[(i,j,r,a,b)],self.X_i[(k,j,s,c,d)],self.lowest_flaeche*weight)
        return
    
    def x_grenze_constraint(self,weight):
        for i in range(self.num_stueck):
            for r in range(2):
                for a in range(self.gesamte_platte_lange):
                    for b in range(self.platte_breite):
                        for j in range(self.num_platte):
                           
                
                       
                        #if j!= int(a/30):
                            #self.bqm.add_quadratic(self.X_ia[(i,a)],self.U_ij[(i,j)],weight)
                            
                        
                            if ((j == int(a/self.platte_lange))and ((a+self.eff_dim[i][r][0])>((j+1)*self.platte_lange))):
                                self.bqm.add_linear(self.X_i[(i,r,a,b)],weight)
                '''
                for b in range(self.platte_breite):
                    if (b+self.eff_dim[i][r][1])>(self.platte_breite):
                        self.bqm.add_linear(self.X_i[(i,r,a,b)],weight)
                '''
        return


    def y_grenze_constraint(self,weight):
        for i in range(self.num_stueck):
            for r in range(2):
                for a in range(self.gesamte_platte_lange):
                    for b in range(self.platte_breite):
                        if ((b+self.eff_dim[i][r][1])>(self.platte_breite)):
                            self.bqm.add_linear(self.X_i[(i,r,a,b)],weight)

    def anzahl_objective(self,weight):
        bias={}
        for i in range(self.num_stueck):
            for j in range(self.num_platte):
                   for r in range(2): #0:nicht umgedrehnt 1:umgedrehnt
                       for a in range(j*self.platte_lange,(j+1)*self.platte_lange-self.eff_dim[i][r][0]+1):
                           for b in range(self.platte_breite - self.eff_dim[i][r][1]+1):
                               bias[self.X_i[(i,j,r,a,b)]]=(a+self.eff_dim[i][r][0])*weight*((j*self.platte_breite)+b+self.eff_dim[i][r][1])
        #for j in range(self.num_platte):
            #self.bqm.add_linear(self.P_j[(j)],-weight)
        self.bqm.add_linear_from(bias)
        return
    
    def reste_objektive(self,weight):
        for j in range(self.num_platte):
            self.bqm.add_linear(self.P_j[(j)],self.platte_lange*self.platte_breite*weight)
            for i in range(self.num_stueck):
                self.bqm.add_linear(self.U_ij[(i,j)],-(self.stueck_lange[i]*self.stueck_breite[i]*weight))
        return
    
    def loop(self):
       self.workflow = hybrid.Loop(
               hybrid.EnergyImpactDecomposer(size=50, rolling=True, rolling_history=0.75)
               | hybrid.QPUSubproblemAutoEmbeddingSampler(sampling_params={'label': '2d_bqm_ker'})
               | hybrid.SplatComposer(), convergence=5)
       
    def call_bqm_solver(self):
        
        sampler = KerberosSampler().sample(self.bqm,max_iter=10,convergence=8,qpu_sampler=DWaveSampler(),qpu_reads=1000,qpu_params={'label': '2d_bqm_kerbig'})
        samplerSET=sampler.samples()
        
        self.solution={}
        for key in samplerSET:
            sampler =key
        for key in sampler:
            if sampler[key] !=0 and "slack" not in key:
                self.solution[key]=sampler[key]
               
        
        '''
        sampler = LeapHybridBQMSampler(token='EbWg-1dc4f5bb6bc7384895496a5dff589cc676d6e1a9')
        raw_sampleset = sampler.sample(self.bqm,label="2d_Problem_hy")
        best_sample = raw_sampleset.first.sample
        self.solution={}
        for key in best_sample:
            if best_sample[key] !=0 and "slack" not in key:
                self.solution[key]=best_sample[key]
        
        
        '''
        return self.solution
    
    def zeichnung(self):
        self.eff_daten=list(key for key in self.solution.keys() if key in self.X_i.values())
        print(self.eff_daten)
        self.ids=[]
        self.i_loc=[]
        self.um=[]
        self.x_achse=[]
        self.y_achse=[]
        for n in self.eff_daten:
                zahlen=re.findall(r"\d+",n)
                ids_pos= list(map(int,zahlen))
                self.ids.append(ids_pos[(0)])
                self.i_loc.append(ids_pos[(1)])
                self.um.append(ids_pos[(2)])
                self.x_achse.append(ids_pos[(3)])
                self.y_achse.append(ids_pos[(4)])
        print(self.ids)
        print(self.i_loc)
        print(self.um)
        print(self.x_achse)
        print(self.y_achse)


        fig = plt.figure()
        ax = fig.add_subplot()
        n=self.num_stueck
        colors=plt.cm.jet(np.linspace(0, 1, n))
        for x,y,i,r,j,c in zip(self.x_achse,self.y_achse,self.ids,self.um,self.i_loc,colors):
                txt=str(i)
                plt.text(x+0.1,y+0.1,txt,fontsize=7)
                rect=mpatch.Rectangle((x,y),self.eff_dim[i][r][0],self.eff_dim[i][r][1],edgecolor = 'green',facecolor = c,fill=True,alpha=0.3)
                ax.add_patch(rect)
        
        ticks=[]
        labels=[]
        for j in range(self.num_platte):
            plt.axvline(x=((j+1)*self.platte_lange), ymax = 0.5 ,ymin=0)
            ticks.append((j+1)*self.platte_lange)
            labels.append('Platte_' + str(j+1))
        plt.xticks(ticks,labels)
        plt.axhline(y=self.platte_breite,xmax=0.5)
        ax.axis([0,2*self.gesamte_platte_lange,0,2*self.platte_breite])
        ax.set_aspect(1)
        plt.show()
        

    def prufung(self):
        print()
        
        #for i in range(1):
            #for a in range(self.gesamte_platte_lange):
                #print(self.bqm.get_linear(self.X_i[(1,0,0,0,5)]))
        #print(self.bqm.get_quadratic(self.X_i[(1,0,12,18)],self.X_i[(3,0,18,18)]))
        
        
if __name__== "__main__":
    a=zweiD_Problem()
    a.effective_dim()
    v=a.define_variables()
    bqm=a.define_bqm()
    
    a.variables_constraints(4)
    
    a.geomerie_constraint(1)
    #a.x_grenze_constraint(300)
    #a.y_grenze_constraint(300)
    
    a.anzahl_objective(0.4)
    #a.stuecke_position_constraint(301)
    
    #a.reste_objektive(200)
    
    #a.prufung()
    #a.loop()
    
    solution= a.call_bqm_solver()
    
    print(solution)
    
    a.zeichnung()
    




      
            