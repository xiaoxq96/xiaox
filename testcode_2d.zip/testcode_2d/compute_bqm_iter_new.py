from dimod import BinaryQuadraticModel
from dwave.system.samplers import LeapHybridBQMSampler
from dwave.system import DWaveSampler, EmbeddingComposite,DWaveCliqueSampler
import datetime
from define_variables_iter_new import Define_variables
from plot_bqm_iter_new import plot
import dimod
import numpy as np
import pandas as pd
from plot_bqm_iter_single_workload import plot as plot_workload
from dimod import BinaryQuadraticModel,quicksum,Binary
from hybrid import traits
from dwave.system.composites import AutoEmbeddingComposite, FixedEmbeddingComposite
from hybrid.core import Runnable, SampleSet
import hybrid
import pandas as pd
import openpyxl
from openpyxl import load_workbook
import os
class QPUSubproblemAutoEmbeddingSampler(traits.SubproblemSampler, traits.SISO, Runnable):
    """A quantum sampler for a subproblem with automated heuristic minor-embedding.
    """
    def __init__(self, num_reads=100, num_retries=0, qpu_sampler=None, sampling_params=None,
                 auto_embedding_params=None, **runopts):
        super(QPUSubproblemAutoEmbeddingSampler, self).__init__(**runopts)
        self.num_reads = num_reads
        self.num_retries = num_retries
        if qpu_sampler is None:
            qpu_sampler = DWaveSampler()
        if sampling_params is None:
            sampling_params = {}
        self.sampling_params = sampling_params
        # embed on the fly and only if needed
        if auto_embedding_params is None:
            auto_embedding_params = {}
        self.sampler = AutoEmbeddingComposite(qpu_sampler, **auto_embedding_params)
        self.qpu_access_time=0
    def __repr__(self):
        return ("{self}(num_reads={self.num_reads!r}, "
                       "qpu_sampler={self.sampler!r}, "
                       "sampling_params={self.sampling_params!r})").format(self=self)

    def next(self, state, **runopts):
        num_reads = runopts.get('num_reads', self.num_reads)
        sampling_params = runopts.get('sampling_params', self.sampling_params)
        params = sampling_params.copy()
        params.update(num_reads=num_reads)
        num_retries = runopts.get('num_retries', self.num_retries)
        embedding_success = False
        num_tries = 0

        while not embedding_success:
            try:
                num_tries += 1
                response = self.sampler.sample(state.subproblem, **params)
                self.qpu_access_time+=response.info['timing']['qpu_access_time']*(0.001)
            except ValueError as exc:
                if num_tries <= num_retries:
                    pass
                else:
                    raise exc
            else:
                embedding_success = True
        return state.updated(subsamples=response)

class KerberosSampler(dimod.Sampler):
    
    """An opinionated dimod-compatible hybrid asynchronous decomposition sampler
    for problems of arbitrary structure and size.

    Examples:
        This example solves a two-variable Ising model.

        >>> import dimod
        >>> import hybrid
        >>> response = hybrid.KerberosSampler().sample_ising(
        ...                     {'a': -0.5, 'b': 1.0}, {('a', 'b'): -1})    # doctest: +SKIP
        >>> response.data_vectors['energy']      # doctest: +SKIP
        array([-1.5])

    """
    properties = None
    parameters = None
    runnable = None

    def __init__(self):
        self.parameters = {
            'num_reads': [],
            'init_sample': [],
            'max_iter': [],
            'max_time': [],
            'convergence': [],
            'energy_threshold': [],
            'sa_reads': [],
            'sa_sweeps': [],
            'tabu_timeout': [],
            'qpu_reads': [],
            'qpu_sampler': [],
            'qpu_params': [],
            'max_subproblem_size': []
        }
        self.properties = {}
        self.QPUSubproblemAutoEmbeddingSampler=QPUSubproblemAutoEmbeddingSampler
    def Kerberos(self,sampler,max_iter=100, max_time=None, convergence=3, energy_threshold=None,
                 sa_reads=1, sa_sweeps=10000, tabu_timeout=500,
                 qpu_reads=100, qpu_sampler=None, qpu_params=None,
                 max_subproblem_size=50):
        """An opinionated hybrid asynchronous decomposition sampler for problems of
        arbitrary structure and size. Runs Tabu search, Simulated annealing and QPU
        subproblem sampling (for high energy impact problem variables) in parallel
        and returns the best samples.

        Kerberos workflow is used by :class:`KerberosSampler`.

        
        Returns:
            Workflow (:class:`~hybrid.core.Runnable` instance).

        """
        #=self.QPUSubproblemAutoEmbeddingSampler(num_reads=qpu_reads, qpu_sampler=qpu_sampler, sampling_params=qpu_params)
        energy_reached = None
        if energy_threshold is not None:
            energy_reached = lambda en: en <= energy_threshold
        iteration = hybrid.Race(
            hybrid.BlockingIdentity(),
            hybrid.InterruptableTabuSampler(
                timeout=tabu_timeout),
            hybrid.InterruptableSimulatedAnnealingProblemSampler(
                num_reads=sa_reads, num_sweeps=sa_sweeps),
            hybrid.EnergyImpactDecomposer(
                size=max_subproblem_size, rolling=True, rolling_history=0.3, traversal='bfs')
                | sampler
                | hybrid.SplatComposer()
        ) | hybrid.ArgMin()

        workflow = hybrid.Loop(iteration, max_iter=max_iter, max_time=max_time,
                               convergence=convergence, terminate=energy_reached)
        return workflow

    def sample(self, bqm,init_sample=None, num_reads=1, max_iter=100, max_time=None, convergence=3, energy_threshold=None,
                 sa_reads=1, sa_sweeps=10000, tabu_timeout=500,
                 qpu_reads=100, qpu_sampler=None, qpu_params=None,
                 max_subproblem_size=50):
            """Run Tabu search, Simulated annealing and QPU subproblem sampling (for
            high energy impact problem variables) in parallel and return the best
            samples.
    
            Sampling Args:
    
                bqm (:obj:`~dimod.BinaryQuadraticModel`):
                    Binary quadratic model to be sampled from.
    
                init_sample (:class:`~dimod.SampleSet`, callable, ``None``):
                    Initial sample set (or sample generator) used for each "read".
                    Use a random sample for each read by default.
    
                num_reads (int):
                    Number of reads. Each sample is the result of a single run of the
                    hybrid algorithm.
    
            Termination Criteria Args:
    
                max_iter (int):
                    Number of iterations in the hybrid algorithm.
    
                max_time (float/None, optional, default=None):
                    Wall clock runtime termination criterion. Unlimited by default.
    
                convergence (int):
                    Number of iterations with no improvement that terminates sampling.
    
                energy_threshold (float, optional):
                    Terminate when this energy threshold is surpassed. Check is
                    performed at the end of each iteration.
    
            Simulated Annealing Parameters:
    
                sa_reads (int):
                    Number of reads in the simulated annealing branch.
    
                sa_sweeps (int):
                    Number of sweeps in the simulated annealing branch.
    
            Tabu Search Parameters:
    
                tabu_timeout (int):
                    Timeout for non-interruptable operation of tabu search (time in
                    milliseconds).
    
            QPU Sampling Parameters:
    
                qpu_reads (int):
                    Number of reads in the QPU branch.
    
                qpu_sampler (:class:`dimod.Sampler`, optional, default=DWaveSampler()):
                    Quantum sampler such as a D-Wave system.
    
                qpu_params (dict):
                    Dictionary of keyword arguments with values that will be used
                    on every call of the QPU sampler.
    
                max_subproblem_size (int):
                    Maximum size of the subproblem selected in the QPU branch.
    
            Returns:
                :obj:`~dimod.SampleSet`: A `dimod` :obj:`.~dimod.SampleSet` object.
    
            """
            if callable(init_sample):
                init_state_gen = lambda: hybrid.State.from_sample(init_sample(), bqm)
            elif init_sample is None:
                init_state_gen = lambda: hybrid.State.from_sample(hybrid.random_sample(bqm), bqm)
            elif isinstance(init_sample, dimod.SampleSet):
                init_state_gen = lambda: hybrid.State.from_sample(init_sample, bqm)
            else:
                raise TypeError("'init_sample' should be a SampleSet or a SampleSet generator")
            sampler=self.QPUSubproblemAutoEmbeddingSampler(num_reads=qpu_reads, qpu_sampler=qpu_sampler, sampling_params=qpu_params)
            self.runnable = self.Kerberos(sampler,max_iter, max_time, convergence, energy_threshold,sa_reads, sa_sweeps, tabu_timeout,qpu_reads, qpu_sampler, qpu_params,
                         max_subproblem_size)
    
            samples = []
            energies = []
            for _ in range(num_reads):
                init_state = init_state_gen()
                final_state = self.runnable.run(init_state)
                # the best sample from each run is one "read"
                ss = final_state.result().samples
                ss.change_vartype(bqm.vartype, inplace=True)
                samples.append(ss.first.sample)
                energies.append(ss.first.energy)
            
            return dimod.SampleSet.from_samples(samples, vartype=bqm.vartype, energy=energies),sampler.qpu_access_time
class BQM():
    def __init__(self,variables,KerberosSampler):
        self.bqm = None        
        self.variables = variables
        self.jobs = variables.jobs
        self.variables_bin_x = variables.variables_bin_x
        self.operation_number_in_job = variables.operation_number_in_job#{Job: Operationnumber}        
        self.machine_number_in_operation = variables.machine_number_in_operation #{(Job,Operation): the number of machines}
        self.machine_in_operation=variables.machine_in_operation # {(Job,Operation): machine_name} 
        self.number_machines=variables.number_machines
        self.processingtimes = variables.processingtimes # {(Job,Operation,machine_name): processingtimes} 
        self.assemblytimes=variables.assemblytimes
        self.transporttimes=variables.transporttimes
        self.T_max=variables.T_max                  #maximum makespan in a loop
        self.priorities=variables.priorities       
        self.list_processingtimes=variables.list_processingtimes
        self.list_assemblytimes=variables.list_assemblytimes
        self.list_transporttimes=variables.list_transporttimes
        self.tasks=variables.tasks
        self.new_tasks=variables.new_tasks
        self.unavailabilities=variables.unavailabilities
        self.resources=variables.resources
        self.resources_operation=variables.resources_operation
        self.resources_names=variables.resources_names
        self.solution=variables.solution           #Solution of a previous loop    
        self.jobs_in_loop=variables.jobs_in_loop
        self.operations_in_loop=variables.operations_in_loop
        self.possible_times=variables.possible_times
        self.a=variables.a
        self.planned_times=variables.planned_times
        self.remaining_tasks=variables.remaining_tasks
        self.extended_max_finish_time=variables.extended_max_finish_time
        self.bottleneck_machine=variables.bottleneck_machine
        self.used_times_machine=variables.used_times_machine
        self.workload_machine=variables.workload_machine
        self.workload={}
        self.KerberosSampler=KerberosSampler
  
    def define_bqm(self):
        """Define BQM model """
        self.bqm = BinaryQuadraticModel('BINARY')
        for variable in self.variables_bin_x:
            self.bqm.add_variable(self.variables_bin_x[variable])
        print ("BQM defined " +str(datetime.datetime.now()))
        return
                      
    def constraint_procedure(self,alpha):
        """Constraint: for each job, all operations are to be pocessed in the specified order
           alpha:weight """
        for i in self.new_tasks:#all the jobs from the current loop
            for j in self.new_tasks[i]:#all operations from the job i of current loop
                j=int(j.replace("Operation",""))
                if j < int(list(self.new_tasks[i].keys())[0].replace("Operation",""))+len(self.new_tasks[i])-1:#except the last operation
                    for m1 in self.machine_in_operation[i,j]:#for the machines of the operation j
                        k=j+1 #the next operation 
                        for m2 in self.machine_in_operation[i,k]:#for the machines of the operation k
                           for t1 in self.possible_times[i,j,m1]: 
                                #t2: The start time of the subsequent operation k in the period between the predecessor time and the finish time of operation j (start time+processing time).
                                #t2 must also not exceed the maximum completion time of all jobs minus the sum of the processingtimes of the operation and the successor time.
                                for t2 in self.possible_times[i,k,m2]:
                                    if t2 - (t1+self.processingtimes[i,j,m1])<0: 
                                        self.bqm.add_quadratic(self.variables_bin_x[(i,j,m1,t1)], self.variables_bin_x[i,k,m2,t2],alpha)       
        print ("Constraint Procedure added " +str(datetime.datetime.now()))
        return
                                
    def constraint_processing(self,beta):
        """Constraint: each operation must start only once on one single machine
           beta:weight"""
        for i in self.new_tasks:#all the jobs from the current loop
            for operation_name in self.new_tasks[i]:#all operations from the job i of current loop
                j=int(operation_name.replace("Operation",""))#operation number
                constraint=[(self.variables_bin_x[(i,j,m,t)],1) for m in self.machine_in_operation[i,j] for t in self.possible_times[i,j,m] ]
                self.bqm.add_linear_equality_constraint(constraint, lagrange_multiplier=beta, constant=-1)
        print ("Constraint Processing added " +str(datetime.datetime.now()))
        return
    
    def constraint_overlapping(self,gamma):
        """Contraint:  The machine cannot process more than one operation at a time.
           gamma :weight"""
        for k in range(len(self.new_tasks)-1): #all the jobs from the current loop
            i=list(self.new_tasks.keys())[k]
            for k2 in range(k+1,len(self.new_tasks)):
                j=list(self.new_tasks.keys())[k2]
                for o_i_name in self.new_tasks[i]:#all operations from the job i of current loop
                    o_i=int(o_i_name.replace("Operation","")) #operation number 
                    for o_j_name in self.new_tasks[j]:#all operations from the job j of current loop
                        o_j=int(o_j_name.replace("Operation",""))#operation number              
                        if len(set(self.machine_in_operation[i,o_i]) & set(self.machine_in_operation[j,o_j]))>0:#Two operations have minmal to select a same machine
                            for m in set(self.machine_in_operation[i,o_i])&set (self.machine_in_operation[j,o_j]):#the same machine from two operations
                                for f in range(self.processingtimes[i,o_i,m]):# during the processing time of the first operation, the second must not start
                                    for t in (set(np.asarray(self.possible_times[i,o_i,m])+f)&set(self.possible_times[j,o_j,m])):# common times   
                                        if t-f in self.possible_times[i,o_i,m] : # case must be assigned  
                                            self.bqm.add_quadratic(self.variables_bin_x[(i,o_i,m,t-f)],self.variables_bin_x[(j,o_j,m,t)],gamma)
                                for f in range(1,self.processingtimes[j,o_j,m]):# during the processing time of the second operation, the first one must not start
                                    for t in (set(self.possible_times[i,o_i,m])&set(np.asarray(self.possible_times[j,o_j,m])+f)):# common times
                                        if t-f in self.possible_times[j,o_j,m] : # case must be assigned
                                            self.bqm.add_quadratic(self.variables_bin_x[(i,o_i,m,t)],self.variables_bin_x[(j,o_j,m,t-f)],gamma)
        print ("Constraint Overlapping added " +str(datetime.datetime.now()))
        return
    
    def objective_makespan(self,weight,number_loop):
        """Makespan objective: all the jobs should be finished in shortest time
        first loop:t+processing times -sum of minimal procesing times of the operations
        rest loop: considering unavaliable and used machine  time 
                  calculate the minimal finish time for all the possible machines, take the minimal time as the estimated finish time of the operation."""
        for i in self.new_tasks:     #all the jobs in current loop
            for o_i_name in self.new_tasks[i]:#all operations from the job i of current loop
                o_i=int(o_i_name.replace("Operation","")) #operation number                 
                for m in self.machine_in_operation[i,o_i]:#assigned machine         
                    for t in self.possible_times[i,o_i,m]:#possible times 
                        if number_loop==0:#first loop
                            if o_i == int(list(self.new_tasks[i].keys())[-1].replace("Operation","")): #last operation of the jobs is weighted double                   
                                if t+self.processingtimes[i,o_i,m]-sum(min(self.list_processingtimes[i,l]) for l in range(int(list(self.new_tasks[i].keys())[0].replace("Operation","")),o_i+1))> 0:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(t+self.processingtimes[i,o_i,m]-sum(min(self.list_processingtimes[i,l]) for l in range(int(list(self.new_tasks[i].keys())[0].replace("Operation","")),o_i+1)))*2*weight)
                            else:
                                if t+self.processingtimes[i,o_i,m]-sum(min(self.list_processingtimes[i,l]) for l in range(int(list(self.new_tasks[i].keys())[0].replace("Operation","")),o_i+1))> 0:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(t+self.processingtimes[i,o_i,m]-sum(min(self.list_processingtimes[i,l]) for l in range(int(list(self.new_tasks[i].keys())[0].replace("Operation","")),o_i+1)))*weight*(o_i-int(list(self.new_tasks[i].keys())[0].replace("Operation",""))+1)/(len(self.new_tasks[i])))
                        else:
                            estimate_finish_time=min(self.possible_times[i,o_i,m])+self.processingtimes[i,o_i,m]#estimate finish time is minimal as possible, so first calculate the shortest finish time of the operation on all possible machines and then take the minimum value
                            for m2 in self.machine_in_operation[i,o_i]:
                                if m2!=m:
                                    if self.possible_times[i,o_i,m2] !=[]:
                                        estimate_finish_time=min(estimate_finish_time,min(self.possible_times[i,o_i,m2])+self.processingtimes[i,o_i,m2])
                            if o_i == int(list(self.new_tasks[i].keys())[-1].replace("Operation","")):      #last operation of the jobs is weighted double                                  
                                if t+self.processingtimes[i,o_i,m]-estimate_finish_time> 0:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(t+self.processingtimes[i,o_i,m]-estimate_finish_time)*2*weight)
                            else:#-self.a[i]-sum(min(self.list_processingtimes[i,l]) for l in range(int(list(self.new_tasks[i].keys())[0].replace("Operation","")),o_i))
                                if t+self.processingtimes[i,o_i,m]-estimate_finish_time> 0:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(t+self.processingtimes[i,o_i,m]-estimate_finish_time)*weight*((o_i-int(list(self.new_tasks[i].keys())[0].replace("Operation",""))+1)/(len(self.new_tasks[i]))))

        print ("Objective Makespan added " +str(datetime.datetime.now()))        
        return
    def objective_rescheduling(self,weight,number_loop):
        
        """Makespan objective: all the jobs should be finished in shortest time
        first loop:t+processing times -sum of minimal procesing times of the operations
        rest loop: considering unavaliable and used machine  time 
                  calculate the minimal finish time for all the possible machines, take the minimal time as the estimated finish time of the operation.
                  """
        for i in self.new_tasks:     #all the jobs in current loop
            for o_i_name in self.new_tasks[i]:#all operations from the job i of current loop
                o_i=int(o_i_name.replace("Operation","")) #operation number                 
                for m in self.machine_in_operation[i,o_i]:#assigned machine         
                    for t in self.possible_times[i,o_i,m]:#possible times 
                        if number_loop==0:#first loop
                            if o_i == int(list(self.new_tasks[i].keys())[-1].replace("Operation","")): #last operation of the jobs                        
                                if t+self.processingtimes[i,o_i,m]-sum(min(self.list_processingtimes[i,l]) for l in range(int(list(self.new_tasks[i].keys())[0].replace("Operation","")),o_i+1))> 0:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(t+self.processingtimes[i,o_i,m]-sum(min(self.list_processingtimes[i,l]) for l in range(int(list(self.new_tasks[i].keys())[0].replace("Operation","")),o_i+1)))*2*weight)
                            else:
                                if t+self.processingtimes[i,o_i,m]-sum(min(self.list_processingtimes[i,l]) for l in range(int(list(self.new_tasks[i].keys())[0].replace("Operation","")),o_i+1))> 0:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(t+self.processingtimes[i,o_i,m]-sum(min(self.list_processingtimes[i,l]) for l in range(int(list(self.new_tasks[i].keys())[0].replace("Operation","")),o_i+1)))*weight*(o_i-int(list(self.new_tasks[i].keys())[0].replace("Operation",""))+1)/(len(self.new_tasks[i])))

                        else:
                            estimate_finish_time=min(self.possible_times[i,o_i,m])+self.processingtimes[i,o_i,m]#estimate finish time is minimal as possible, so first calculate the shortest finish time of the operation on all possible machines and then take the minimum value
                            for m2 in self.machine_in_operation[i,o_i]:
                                if m2!=m:
                                    if self.possible_times[i,o_i,m2] !=[]:
                                        estimate_finish_time=min(estimate_finish_time,min(self.possible_times[i,o_i,m2])+self.processingtimes[i,o_i,m2])

                            if o_i == int(list(self.new_tasks[i].keys())[-1].replace("Operation","")):                                       
                                if t+self.processingtimes[i,o_i,m]-estimate_finish_time> 0:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(t+self.processingtimes[i,o_i,m]-estimate_finish_time)*2*weight)
                            else:#-self.a[i]-sum(min(self.list_processingtimes[i,l]) for l in range(int(list(self.new_tasks[i].keys())[0].replace("Operation","")),o_i))
                                if t+self.processingtimes[i,o_i,m]-estimate_finish_time> 0:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(t+self.processingtimes[i,o_i,m]-estimate_finish_time)*weight*((o_i-int(list(self.new_tasks[i].keys())[0].replace("Operation",""))+1)/(len(self.new_tasks[i]))))

        print ("Objective Makespan added " +str(datetime.datetime.now()))        
        return
    def objective_priority_on_time(self,weight,current_time,priority_change):            
        priority={}
        if priority_change=='True':
            for i in range(len(self.jobs)):
                if current_time<self.jobs[i+1]['priority'][0]:
                    priority[i+1]=0
                elif current_time>self.jobs[i+1]['priority'][1]:
                    priority[i+1]=15
                else:
                    priority[i+1]=(current_time-self.jobs[i+1]['priority'][0])/(self.jobs[i+1]['priority'][1]-self.jobs[i+1]['priority'][0])*10
        else:
            for i in range(len(self.jobs)):
                priority[i+1]=self.jobs[i+1]['priority'][2]
        for i in self.new_tasks:     #all the jobs in current loop
            for o_i_name in self.new_tasks[i]:#all operations from the job i of current loop
                o_i=int(o_i_name.replace("Operation","")) #operation number                 
                for m in self.machine_in_operation[i,o_i]:    
                    for t in self.possible_times[i,o_i,m]:     
                        if number_loop==0:                            
                            if o_i==self.operation_number_in_job[i]:#last operation for the jobs in the current loop is the last operation of the jobs 
                                if self.jobs[i]['priority'][1]-t-self.processingtimes[i,o_i,m]>0:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(self.jobs[i]['priority'][1]-t-self.processingtimes[i,o_i,m])*priority[i]*2*weight)
                                else:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(t+self.processingtimes[i,o_i,m]-self.jobs[i]['priority'][1])*priority[i]*2*weight)
                            else:
                                if self.jobs[i]['priority'][1]-t-self.processingtimes[i,o_i,m]-sum(min(self.list_processingtimes[i,l]) for l in range(o_i+1,int(list(self.new_tasks[i].keys())[0].replace("Operation",""))+len(self.new_tasks[i])))>0:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(self.jobs[i]['priority'][1]-t-self.processingtimes[i,o_i,m]-sum(min(self.list_processingtimes[i,l]) for l in range(o_i+1,int(list(self.new_tasks[i].keys())[0].replace("Operation",""))+len(self.new_tasks[i]))))*priority[i]*weight*(o_i-int(list(self.new_tasks[i].keys())[0].replace("Operation",""))+1)/(len(self.new_tasks[i])))
                                else:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(t+self.processingtimes[i,o_i,m]+sum(min(self.list_processingtimes[i,l]) for l in range(o_i+1,int(list(self.new_tasks[i].keys())[0].replace("Operation",""))+len(self.new_tasks[i])))-self.jobs[i]['priority'][1])*priority[i]*weight*(o_i-int(list(self.new_tasks[i].keys())[0].replace("Operation",""))+1)/(len(self.new_tasks[i])))
                        else:
                            estimate_finish_time=max(self.possible_times[i,o_i,m])+self.processingtimes[i,o_i,m]#estimate finish time is minimal as possible, so first calculate the shortest finish time of the operation on all possible machines and then take the minimum value
                            for m2 in self.machine_in_operation[i,o_i]:
                                if m2!=m:
                                    if self.possible_times[i,o_i,m2] !=[]:
                                        estimate_finish_time=max(estimate_finish_time,max(self.possible_times[i,o_i,m2])+self.processingtimes[i,o_i,m2])
                            if o_i==self.operation_number_in_job[i]:#last operation for the jobs in the current loop is the last operation of the jobs 
                                if self.jobs[i]['priority'][1]-t-self.processingtimes[i,o_i,m]>0:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(self.jobs[i]['priority'][1]-t-self.processingtimes[i,o_i,m])*2*weight)
                                else:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(t+self.processingtimes[i,o_i,m]-self.jobs[i]['priority'][1])*2*weight)
                            elif o_i ==int(list(self.new_tasks[i].keys())[-1].replace("Operation","")) :
                                if estimate_finish_time-t-self.processingtimes[i,o_i,m]>0:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(estimate_finish_time-t-self.processingtimes[i,o_i,m])*priority[i]*2*weight)
                            else:
                                if estimate_finish_time-t-self.processingtimes[i,o_i,m]>0:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(estimate_finish_time-t-self.processingtimes[i,o_i,m])*priority[i]*weight*(o_i-int(list(self.new_tasks[i].keys())[0].replace("Operation",""))+1)/(len(self.new_tasks[i])))
        print ("Objective Priority and on time added " +str(datetime.datetime.now()))   
        return
    
    def objective_priority_makespan(self,weight_makespan,weight_priority,current_time,priority_change): 
        """objective which combines the priority rule and the makespan
        the corresponding weights 'weight_makespan','weight_priority' can be manipulated independently which determine the strength of the objective"""           
        priority={}
        if priority_change=='True':
            for i in range(len(self.jobs)):
                if current_time<self.jobs[i+1]['priority'][0]:
                    priority[i+1]=0
                elif current_time>self.jobs[i+1]['priority'][1]:
                    priority[i+1]=15
                else:
                    priority[i+1]=(current_time-self.jobs[i+1]['priority'][0])/(self.jobs[i+1]['priority'][1]-self.jobs[i+1]['priority'][0])*10
        else:
            for i in range(len(self.jobs)):
                priority[i+1]=self.jobs[i+1]['priority'][2]
        for i in self.new_tasks:  #each job for the current loop
            for o_i_name in self.new_tasks[i]:#all operations from the job i of current loop
                o_i=int(o_i_name.replace("Operation","")) #operation number                 
                for m in self.machine_in_operation[i,o_i]:    
                    for t in self.possible_times[i,o_i,m]: 
                        if number_loop==0:#first loop
                            if o_i == int(list(self.new_tasks[i].keys())[-1].replace("Operation","")): #last operation in current loop                               
                                if t+self.processingtimes[i,o_i,m]-sum(min(self.list_processingtimes[i,l]) for l in range(int(list(self.new_tasks[i].keys())[0].replace("Operation","")),o_i+1))> 0:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(t+self.processingtimes[i,o_i,m]-sum(min(self.list_processingtimes[i,l]) for l in range(int(list(self.new_tasks[i].keys())[0].replace("Operation","")),o_i+1)))*2*(priority[i]*0.1*weight_priority+weight_makespan))
                            else:
                                if t+self.processingtimes[i,o_i,m]-sum(min(self.list_processingtimes[i,l]) for l in range(int(list(self.new_tasks[i].keys())[0].replace("Operation","")),o_i+1))> 0:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(t+self.processingtimes[i,o_i,m]-sum(min(self.list_processingtimes[i,l]) for l in range(int(list(self.new_tasks[i].keys())[0].replace("Operation","")),o_i+1)))*(priority[i]*0.1*weight_priority+weight_makespan)*(o_i-int(list(self.new_tasks[i].keys())[0].replace("Operation",""))+1)/(len(self.new_tasks[i])))
                        else:#next loops
                            estimate_finish_time=min(self.possible_times[i,o_i,m])+self.processingtimes[i,o_i,m]
                            for m2 in self.machine_in_operation[i,o_i]:
                                if m2!=m:
                                    if self.possible_times[i,o_i,m2] !=[]:
                                        estimate_finish_time=min(estimate_finish_time,min(self.possible_times[i,o_i,m2])+self.processingtimes[i,o_i,m2])

                            if o_i == int(list(self.new_tasks[i].keys())[-1].replace("Operation","")):                                       
                                if t+self.processingtimes[i,o_i,m]-estimate_finish_time> 0:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(t+self.processingtimes[i,o_i,m]-estimate_finish_time)*2*(priority[i]*0.1*weight_priority+weight_makespan))
                            else:#-self.a[i]-sum(min(self.list_processingtimes[i,l]) for l in range(int(list(self.new_tasks[i].keys())[0].replace("Operation","")),o_i))
                                if t+self.processingtimes[i,o_i,m]-estimate_finish_time> 0:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(t+self.processingtimes[i,o_i,m]-estimate_finish_time)*(priority[i]*0.1*weight_priority+weight_makespan)*((o_i-int(list(self.new_tasks[i].keys())[0].replace("Operation",""))+1)/(len(self.new_tasks[i]))))
        print ("Objective Priority and makespan added " +str(datetime.datetime.now()))   
        return
   
    def single_objective_workload_balancing(self,weight): 
        """Define workload objective. Determines the distribution of operations on the machines. 
           weight: weight of objective
           Objective: balancing the workload"""       
        #for m in range(1,self.number_machines+1): 
            #if m in list(int(machine_number) for i in self.tasks for j in range(1,len(self.tasks[i])+1) for machine_number in self.machine_in_operation[i,j] ): #if all the operations can not be assigned to the machine, the workload of this machine should not be considered.       
        self.workload=self.workload_machine   
        workload_sum_average=[(self.variables_bin_x[i,int(o_i.replace("Operation","")),m2],-1*self.processingtimes[i,int(o_i.replace("Operation","")),m2]/(len(self.workload.keys()))) for i in self.new_tasks for o_i in self.new_tasks[i] for m2 in self.machine_in_operation[i,int(o_i.replace("Operation",""))] ]        
        for m in  range(1,self.number_machines+1):
            if m in list(int(machine_number) for i in self.tasks for j in range(1,len(self.tasks[i])+1) for machine_number in self.machine_in_operation[i,j] ): #if all the operations can not be assigned to the machine, the workload of this machine should not be considered.       
               
                constant=self.workload[m]-sum(self.workload[m2] for m2 in  self.workload.keys())/(len(self.workload.keys()))
                objective=[(self.variables_bin_x[i,int(o_i.replace("Operation","")),m],self.processingtimes[i,int(o_i.replace("Operation","")),m]) for i in self.new_tasks for o_i in self.new_tasks[i] for m2 in self.machine_in_operation[i,int(o_i.replace("Operation",""))] if m==m2]
                self.bqm.add_linear_equality_constraint(objective+workload_sum_average, lagrange_multiplier=weight,constant=constant)                        
        return
   
    def single_objective_workload_minimization(self,weight):
        """Determines the sum of all workloads of the operations on the machines
        weight: weight of objective"""
        for i in self.new_tasks:     #all the jobs in current loop
            for o_i_name in self.new_tasks[i]:#all operations from the job i of current loop
                o_i=int(o_i_name.replace("Operation","")) #operation number
                for m in self.machine_in_operation[i,o_i]:#assigned machine         
                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m)],(self.processingtimes[i,o_i,m]-min(self.list_processingtimes[i,o_i]))*weight)
        return
    
    def constraint_assignment_workload_single(self,weight):
        """Constraint: each operation must start only once on one single machine
           weight: weight of constraint"""
        for i in self.new_tasks:#all the jobs from the current loop
            for operation_name in self.new_tasks[i]:#all operations from the job i of current loop
                j=int(operation_name.replace("Operation",""))#operation number
                constraint=[(self.variables_bin_x[(i,j,m)],1) for m in self.machine_in_operation[i,j]] 
                self.bqm.add_linear_equality_constraint(constraint, lagrange_multiplier=weight, constant=-1)
        print ("Constraint assignment added " +str(datetime.datetime.now()))
        return
    
    def objective_workload_minimization(self,weight):
        """Determines the sum of all workloads of the operations on the machines
        weight: weight of objective"""
        for i in self.new_tasks:     #all the jobs in current loop
            for o_i_name in self.new_tasks[i]:#all operations from the job i of current loop
                o_i=int(o_i_name.replace("Operation","")) #operation number
                for m in self.machine_in_operation[i,o_i]:#assigned machine         
                    for t in self.possible_times[i,o_i,m]:#possible times 
                        self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(self.processingtimes[i,o_i,m]-min(self.list_processingtimes[i,o_i]))*weight)             #the processing times will be minimized                           
        return
    
    def objective_workload_balancing(self,weight):   
        """Define workload objective. Determines the distribution of operations on the machines. 
           weight: weight of objective
           Objective: balancing the workload"""
        for m in range(1,self.number_machines+1): 
            if m in list(int(machine_number) for i in self.tasks for j in range(1,len(self.tasks[i])+1) for machine_number in self.machine_in_operation[i,j] ): #if all the operations can not be assigned to the machine, the workload of this machine should not be considered.       
                self.workload[m]=self.workload_machine[m]          
        workload_sum_average=[(self.variables_bin_x[i,int(o_i.replace("Operation","")),m2,t],-1*self.processingtimes[i,int(o_i.replace("Operation","")),m2]/(len(self.workload.keys()))) for i in self.new_tasks for o_i in self.new_tasks[i] for m2 in self.machine_in_operation[i,int(o_i.replace("Operation",""))] for t in self.possible_times[i,int(o_i.replace("Operation","")),m2] if len(self.machine_in_operation[i,int(o_i.replace("Operation",""))])>1]        
        for m in  range(1,self.number_machines+1):              
            if m in list(int(machine_number) for i in self.tasks for j in range(1,len(self.tasks[i])+1) for machine_number in self.machine_in_operation[i,j] ): #if all the operations can not be assigned to the machine, the workload of this machine should not be considered.       
                constant=self.workload[m]-sum(self.workload[m2] for m2 in  range(1,self.number_machines+1))/(len(self.workload.keys())) #workload on machine-average workload of each machine
                objective=[(self.variables_bin_x[i,int(o_i.replace("Operation","")),m,t],self.processingtimes[i,int(o_i.replace("Operation","")),m]) for i in self.new_tasks for o_i in self.new_tasks[i] for m2 in self.machine_in_operation[i,int(o_i.replace("Operation",""))] for t in self.possible_times[i,int(o_i.replace("Operation","")),m2] if m==m2 and len(self.machine_in_operation[i,int(o_i.replace("Operation",""))])>1]
                self.bqm.add_linear_equality_constraint(objective+workload_sum_average, lagrange_multiplier=weight,constant=constant) 
        """for m in self.number_machines:            
            self.workload[m]=len(self.used_times_machine[m])
            fixed_workload[m]=sum(self.processingtimes[i,j,m] for i in self.remaining_tasks for j in self.remaining_tasks[i] if len(self.machine_in_operation[i,int(j.replace("Operation",""))])==1 and self.machine_in_operation[i,int(j.replace("Operation",""))][0]==m)
            fixed_workload[m]=fixed_workload[m]+sum(self.processingtimes[i,j,m] for i in self.new_tasks for j in self.new_tasks[i] if len(self.machine_in_operation[i,int(j.replace("Operation",""))])==1 and self.machine_in_operation[i,int(j.replace("Operation",""))][0]==m)

        for i in self.new_tasks:     #all the jobs in current loop
            for o_i_name in self.new_tasks[i]:#all operations from the job i of current loop
                o_i=int(o_i_name.replace("Operation","")) #operation number
                if len(self.machine_in_operation[i,o_i])!=1:
                    for m in self.machine_in_operation[i,o_i]:#assigned machine         
                        for t in self.possible_times[i,o_i,m]:#possible times 
                            self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(fixed_workload[m]+self.processingtimes[i,o_i,m]-min(fixed_workload[m2]+self.processingtimes[i,o_i,m2] for m2 in self.machine_in_operation[i,o_i]))*weight)
        """
        return
   
    def objective_on_time(self,weight,number_loop):
        """Define on time objective. Each job should be finished on the defined time..
           weight: weight of objective"""
        for i in self.new_tasks:     #all the jobs in current loop
            for o_i_name in self.new_tasks[i]:#all operations from the job i of current loop
                o_i=int(o_i_name.replace("Operation","")) #operation number                 
                for m in self.machine_in_operation[i,o_i]:    
                    for t in self.possible_times[i,o_i,m]:     
                        if number_loop==0:                            
                            if o_i==self.operation_number_in_job[i]:#last operation for the jobs in the current loop is the last operation of the jobs 
                                if self.jobs[i]['priority'][1]-t-self.processingtimes[i,o_i,m]>0:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(self.jobs[i]['priority'][1]-t-self.processingtimes[i,o_i,m])*2*weight)
                                else:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(t+self.processingtimes[i,o_i,m]-self.jobs[i]['priority'][1])*2*weight)
                            else:
                                if self.jobs[i]['priority'][1]-t-self.processingtimes[i,o_i,m]-sum(min(self.list_processingtimes[i,l]) for l in range(o_i+1,int(list(self.new_tasks[i].keys())[0].replace("Operation",""))+len(self.new_tasks[i])))>0:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(self.jobs[i]['priority'][1]-t-self.processingtimes[i,o_i,m]-sum(min(self.list_processingtimes[i,l]) for l in range(o_i+1,int(list(self.new_tasks[i].keys())[0].replace("Operation",""))+len(self.new_tasks[i]))))*weight*(o_i-int(list(self.new_tasks[i].keys())[0].replace("Operation",""))+1)/(len(self.new_tasks[i])))
                                else:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(t+self.processingtimes[i,o_i,m]+sum(min(self.list_processingtimes[i,l]) for l in range(o_i+1,int(list(self.new_tasks[i].keys())[0].replace("Operation",""))+len(self.new_tasks[i])))-self.jobs[i]['priority'][1])*weight*(o_i-int(list(self.new_tasks[i].keys())[0].replace("Operation",""))+1)/(len(self.new_tasks[i])))
                        else:
                            estimate_finish_time=max(self.possible_times[i,o_i,m])+self.processingtimes[i,o_i,m]#estimate finish time is minimal as possible, so first calculate the shortest finish time of the operation on all possible machines and then take the minimum value
                            for m2 in self.machine_in_operation[i,o_i]:
                                if m2!=m:
                                    if self.possible_times[i,o_i,m2] !=[]:
                                        estimate_finish_time=max(estimate_finish_time,max(self.possible_times[i,o_i,m2])+self.processingtimes[i,o_i,m2])
                            if o_i==self.operation_number_in_job[i]:#last operation for the jobs in the current loop is the last operation of the jobs 
                                
                                if self.jobs[i]['priority'][1]-t-self.processingtimes[i,o_i,m]>0:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(self.jobs[i]['priority'][1]-t-self.processingtimes[i,o_i,m])*2*weight)
                                else:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(t+self.processingtimes[i,o_i,m]-self.jobs[i]['priority'][1])*2*weight)

                            elif o_i ==int(list(self.new_tasks[i].keys())[-1].replace("Operation","")): 
                                if estimate_finish_time-t-self.processingtimes[i,o_i,m]>0:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(estimate_finish_time-t-self.processingtimes[i,o_i,m])*2*weight)
                            else:
                                if estimate_finish_time-t-self.processingtimes[i,o_i,m]>0:
                                    self.bqm.add_linear(self.variables_bin_x[(i,o_i,m,t)],(estimate_finish_time-t-self.processingtimes[i,o_i,m])*weight*(o_i-int(list(self.new_tasks[i].keys())[0].replace("Operation",""))+1)/(len(self.new_tasks[i])))                                                
        print ("Objective On Time added " +str(datetime.datetime.now()))  
        return
    
    def make_reverse_anneal_schedule(self,s_target=0.0, hold_time=10.0, ramp_back_slope=0.2, ramp_up_time=0.0201,
                                     ramp_up_slope=None):
        """Build annealing waveform pattern for reverse anneal feature.
        Waveform starts and ends at s=1.0, descending to a constant value
        s_target in between, following a linear ramp.
          s_target:   s-parameter to descend to (between 0 and 1)
          hold_time:  amount of time (in us) to spend at s_target (must be >= 2.0us)
          ramp_slope: slope of transition region, in units 1/us
        """
        # validate parameters
        if s_target < 0.0 or s_target > 1.0:
            raise ValueError("s_target must be between 0 and 1")
        if hold_time < 0.0:
            raise ValueError("hold_time must be >= 0")
        if ramp_back_slope > 0.2:
            raise ValueError("ramp_back_slope must be <= 0.2")
        if ramp_back_slope <= 0.0:
            raise ValueError("ramp_back_slope must be > 0")
        ramp_time = (1.0 - s_target) / ramp_back_slope
        initial_s = 1.0
        pattern = [[0.0, initial_s]]
        # don't add new points if s_target == 1.0
        if s_target < 1.0:
            pattern.append([round(ramp_time, 4), round(s_target, 4)])
            if hold_time != 0:
                pattern.append([round(ramp_time+hold_time, 4), round(s_target, 4)])
        # add last point
        if ramp_up_slope is not None:
            ramp_up_time = (1.0-s_target)/ramp_up_slope
            pattern.append([round(ramp_time + hold_time + ramp_up_time, 4), round(1.0, 4)])
        else:
            pattern.append([round(ramp_time + hold_time + ramp_up_time, 4), round(1.0, 4)])
        return pattern                    
    
    
    def call_bqm_solver_Kerberos(self,max_iter,convergence,num_reads,solver):
        """Calls Kerberos Solver"""
        sampler,qpu_access_time = self.KerberosSampler.sample(self.bqm,max_iter=max_iter,convergence=convergence,qpu_sampler=solver,qpu_params={'label': 'JSSP_bqm_iter'},qpu_reads=num_reads)
        samplerSET=sampler.samples()
        solution=[]
        for key in samplerSET:
            sampler =key
        for key in sampler:
            if sampler[key] !=0:
                solution.append((key,sampler[key]))
        return solution,qpu_access_time
    
    def call_bqm_solver_Kerberos_with_reverse_annealing(self,max_iter,convergence,num_reads,solver):
        """with reverse annealing"""    
        sampler=DWaveSampler()
        max_slope = 1.0/sampler.properties["annealing_time_range"][0]
        reverse_schedule=self.make_reverse_anneal_schedule(s_target=0.4, hold_time=180, ramp_up_slope=max_slope)
        time_total = reverse_schedule[3][0]
        forward_answer,qpu_access_time1 = self.KerberosSampler.sample(self.bqm,max_iter=max_iter,convergence=convergence,max_time=time_total,qpu_sampler=DWaveSampler(),qpu_params={'label': 'JSSP_bqm_iter_reverse'},qpu_reads=num_reads)
        forward_solutions, forward_energies = forward_answer.record.sample, forward_answer.record.energy
        i5 = int(5.0/95*len(forward_answer))  # Index i5 is about a 5% indexial move from the sample of lowest energy
        initial = dict(zip(forward_answer.variables, forward_answer.record[i5].sample))
        reverse_anneal_params = dict(anneal_schedule=reverse_schedule, initial_state=initial, reinitialize_state=False)        
        sampler,qpu_access_time2 = self.KerberosSampler.sample(self.bqm,max_iter=max_iter,convergence=convergence,qpu_sampler=DWaveSampler(),qpu_params=reverse_anneal_params,qpu_reads=num_reads)
        samplerSET=sampler.samples()
        solution=[]
        for key in samplerSET:
            sampler =key
        for key in sampler:
            if sampler[key] !=0 and "slack" not in key:
                solution.append((key,sampler[key]))
        qpu_access_time=qpu_access_time1+qpu_access_time2
        return solution,qpu_access_time
    
    def call_bqm_solver_classic(self):#write the related parameters
        iteration = hybrid.RacingBranches(
        hybrid.InterruptableTabuSampler(num_reads=None, tenure=None, timeout=100, initial_states_generator='random'),
        hybrid.EnergyImpactDecomposer(size=2)
        | hybrid.SimulatedAnnealingSubproblemSampler(num_reads=None, num_sweeps=1000,
                 beta_range=None, beta_schedule_type='geometric',
                 initial_states_generator='random')
        | hybrid.SplatComposer()
        ) | hybrid.ArgMin()
        workflow = hybrid.LoopUntilNoImprovement(iteration, convergence=3)
    
        # Solve the problem
        init_state = hybrid.State.from_problem(self.bqm)
        final_state = workflow.run(init_state).result()
        solution=[]
        for key in final_state.samples.first.sample:            
            if final_state.samples.first.sample[key] !=0:
                solution.append((key,final_state.samples.first.sample[key]))       
        return solution
        

    def check_constraint(self,solution,priority):
        """Check if the solution fulfills all the constraints
        check_constraint:True: Every constraint is fulfilled
        analyze the priority of the jobs  for each loop
        priority_analysis:Quantifying the priority rule: If the job with higher priority, Its finishing time cannot be delayed by jobs that have a lower priority than it
        dictionary plan: {job number:operation number:[machine number,startingtimes]} all the obtained solutions
        """
        plan={}#initialize the solution
        check_constraint=True
        for i in self.jobs.keys():#all the jobs 
            plan[i]={}
            for o_i_name in self.jobs[i]['task'].keys():#all operations from the job i of current loop
                j=int(o_i_name.replace("Operation",""))#operation number 
                check_once=0
                for m in self.machine_in_operation[i,j]:#for the machines of the operation j
                    for t in range(max(self.jobs[a]["priority"][1]+self.extended_max_finish_time for a in self.jobs.keys())):                        
                        if ("x%s_%s_%s_%s"%(str(i),str(j),str(m),str(t)),1) in solution:#the operation starts on the machine m 
                            check_once+=1
                            plan[i][j]=[m,t]
                if check_once>1:
                    check_constraint=False
                    print(self.possible_times[i,j,m] for m in self.machine_in_operation[i,j])
                    print("Processing constraint is not fulfilled ")
        for i in self.new_tasks.keys():#all the jobs from the current loop
            for o_i_name in self.new_tasks[i].keys():#all operations from the job i of current loop
                j=int(o_i_name.replace("Operation",""))#operation number 
                if j not in plan[i].keys() :
                    for m in self.machine_in_operation[i,j]:
                        print(i,j,m,self.possible_times[i,j,m])
                    print("%d%d Processing constraint is not fulfilled "%(i,j))
                    check_constraint=False
        for i in plan.keys():#all the jobs in the solution
            for j in plan[i].keys():#all operations from the job i in the solution
                
                if j <int(list(plan[i].keys())[-1]):#except last operation in the solution
                    k=j+1#the next operation                    
                    if plan[i][k][1]-plan[i][j][1]<self.processingtimes[i,j,plan[i][j][0]]:
                        print(self.possible_times[i,j,plan[i][j][0]],self.possible_times[i,k,plan[i][k][0]])
                        print("j%d_o%d_o%d Procedure constraint not fulfilled"%(i,j,k)+str(plan[i][k][1]-plan[i][j][1]-self.processingtimes[i,j,plan[i][j][0]]))
                        check_constraint=False
        for i in plan.keys(): #all the jobs from the current loop
            for o_i in plan[i].keys():#all operations from the job i of current loop
                for j in plan.keys():#all jobs other than job i
                    if i!=j:
                        for o_j in plan[j].keys():#all operations from the job j of current loop
                            if plan[i][o_i][0]==plan[j][o_j][0]:#the same machine                               
                                if plan[i][o_i][1]>=plan[j][o_j][1]:
                                    if plan[i][o_i][1]-plan[j][o_j][1]<self.processingtimes[j,o_j,plan[j][o_j][0]]:#overlapping 
                                        print("Overlapping constraint  is not fulfilled"+str(i)+str(o_i)+str(j)+str(o_j))
                                        check_constraint=False
                                        print(i,o_i,j,o_j,self.possible_times[i,o_i,plan[i][o_i][0]],self.possible_times[j,o_j,plan[j][o_j][0]])
                                if plan[i][o_i][1]<=plan[j][o_j][1]:
                                    if plan[j][o_j][1]-plan[i][o_i][1]<self.processingtimes[i,o_i,plan[i][o_i][0]]:#overlapping
                                        print("Overlapping Constraint is not fulfilled"+str(i)+str(o_i)+str(j)+str(o_j))
                                        check_constraint=False
                                        print(i,o_i,j,o_j,self.possible_times[i,o_i,plan[i][o_i][0]],self.possible_times[j,o_j,plan[j][o_j][0]])
        priority_analysis=0#initialization
        #for i in plan.keys(): #all the jobs from the current loop
            
        for i in self.new_tasks.keys():
            for j in plan.keys():
                for o_i_name in self.new_tasks[i].keys():#all operations from the job i of current loop
                    o_i=int(o_i_name.replace("Operation",""))
                    for o_j in plan[j].keys():
                        if self.priorities[i][2]>self.priorities[j][2]:
                            value=0
                            if plan[i][o_i][1]>min(min(self.possible_times[i,o_i,m2]) for m2 in self.machine_in_operation[i,o_i]):#if plan[i][o_i][1]>min(self.possible_times[i,o_i,plan[i][o_i][0]]):                                        
                                if min(min(self.possible_times[i,o_i,m2])+self.processingtimes[i,o_i,m2] for m2 in self.machine_in_operation[i,o_i])<min(self.possible_times[i,o_i,plan[i][o_i][0]])+self.processingtimes[i,o_i,plan[i][o_i][0]]:
                                    for m in self.machine_in_operation[i,o_i]:
                                        
                                        if min(min(self.possible_times[i,o_i,m2]) for m2 in self.machine_in_operation[i,o_i])==min(self.possible_times[i,o_i,m]) and m!=plan[i][o_i][0]:                                             
                                           if plan[j][o_j][0]==m and plan[j][o_j][1] in range(min(self.possible_times[i,o_i,m])-self.processingtimes[j,o_j,m]+1,min(self.possible_times[i,o_i,m])+self.processingtimes[i,o_i,m]) :
                                                priority_analysis+=abs(plan[i][o_i][1]-min(self.possible_times[i,o_i,m]))*(self.priorities[i][2]/self.priorities[j][2])
                                                if priority==True:
                                                    print(m,j,o_j,i,o_i)
                                                    print("Priority rule for Job%d%d and Job%d%d is not fulfilled,the value of priority analysis: %d"%(i,o_i,j,o_j,plan[i][o_i][1]-min(self.possible_times[i,o_i,m])))
                                                    value+=1
                                else:
                                    if plan[j][o_j][0]==plan[i][o_i][0] and plan[j][o_j][1] in range(min(self.possible_times[i,o_i,plan[i][o_i][0]])-self.processingtimes[j,o_j,plan[i][o_i][0]]+1,min(self.possible_times[i,o_i,plan[i][o_i][0]])+self.processingtimes[i,o_i,plan[i][o_i][0]]):
                                        priority_analysis+=abs(plan[i][o_i][1]-min(self.possible_times[i,o_i,plan[i][o_i][0]]))*(self.priorities[i][2]/self.priorities[j][2])
                                        if priority==True:
                                            print("Priority rule for Job%d%d and Job%d%d is not fulfilled,the value of priority analysis: %d"%(i,o_i,j,o_j,plan[i][o_i][1]-min(self.possible_times[i,o_i,plan[i][o_i][0]])))                                            
        return check_constraint,priority_analysis
        
        
    def check_solution(self,solution,on_time,priority,workload_balancing,workload_minimization,solution_optimal_makespan,solution_optimal_priority,solution_optimal_workload_balance,solution_optimal_workload_minimization):
        """To calculate the makespan, workload balance and workload minimization for the solution
        For the on time objective, check if all the jobs are finished ontime and calculate the tardiness
        value: for the on time: tardiness;  makespan:makespan
        dictionary plan: {job number:operation number:[machine number,startingtimes]} obtained solution after the end of the iteration
        workload_machine {machine number:  workload(sum of the processingtimes)}
        average_workload the average workload for each machine: sum of the workload/number of machines
        workload_balance: the sum of workload difference between average workload and workload of the each machine  """
        plan={}
        workload_machine={}
        makespan=0
        for i in self.jobs.keys():#all the jobs 
            plan[i]={}
            for o_i_name in self.jobs[i]['task'].keys():#all operations from the job i of current loop
                j=int(o_i_name.replace("Operation",""))#operation number 
                check_once=0
                for m in self.machine_in_operation[i,j]:#for the machines of the operation j
                    for t in range(max(self.jobs[a]["priority"][1]+self.extended_max_finish_time for a in self.jobs.keys())):                        
                        if ("x%s_%s_%s_%s"%(str(i),str(j),str(m),str(t)),1) in solution:#the operation starts on the machine m 
                            check_once+=1
                            plan[i][j]=[m,t]
                            if makespan<t+self.processingtimes[i,j,m]:
                                makespan=t+self.processingtimes[i,j,m]        

        for m in range(1,self.number_machines+1):
            if m in list(int(machine_number) for i in self.tasks for j in range(1,len(self.tasks[i])+1) for machine_number in self.machine_in_operation[i,j] ): #if all the operations can not be assigned to the machine, the workload of this machine should not be considered.       
                workload_machine[m]=0
        for i in plan.keys():
            for j in plan[i]:
                workload_machine[plan[i][j][0]]+=self.processingtimes[i,j,plan[i][j][0]]  
        average_workload=sum(workload_machine[m] for m in workload_machine.keys())/(len(workload_machine.keys()))
        workload_balance=sum((workload_machine[m]-average_workload)**2 for m in workload_machine.keys())**0.5
        if solution_optimal_makespan!=[] and  solution_optimal_workload_balance!=[]:
            pass
        print("The workload balance is: "+str(workload_balance))        
        minimal_workload=sum(min(self.list_processingtimes[i,int(j.replace("Operation",""))]) for i in self.jobs.keys() for j in self.jobs[i]['task'])
        workload_difference=sum(workload_machine[m] for m in workload_machine.keys())-minimal_workload  
        print("The difference of workload between the solution and the minimal workload is: "+str(workload_difference))
        if on_time==True:
            sum_tardiness=0
            for i in plan.keys():
                tardiness=plan[i][self.operation_number_in_job[i]][1]+self.processingtimes[i,self.operation_number_in_job[i],plan[i][self.operation_number_in_job[i]][0]]-self.priorities[i][1]
                sum_tardiness+=abs(tardiness)
                if tardiness!=0:
                    print("Job%d is not finished on time with tardiness%d"%(i,tardiness))
            print("The sum of all tardiness is: %d"%(sum_tardiness))
            value=sum_tardiness
        else:
            value=makespan  
        """if priority==True:
            time_differences=0
            for i in range(1,len(self.jobs)):
                for j in range(i+1,len(self.jobs)+1):                    
                    time_i=plan[i][self.operation_number_in_job[i]][1]+self.processingtimes[i,self.operation_number_in_job[i],plan[i][self.operation_number_in_job[i]][0]]
                    time_j=plan[j][self.operation_number_in_job[j]][1]+self.processingtimes[j,self.operation_number_in_job[j],plan[j][self.operation_number_in_job[j]][0]]
                    
                    if self.priorities[i][2]>self.priorities[j][2] and time_i>time_j:
                        print("Priority rule for Job%d and Job%d is not fulfilled, time difference: %d"%(i,j,time_i-time_j))
                        time_differences+=abs(time_i-time_j)
                    if self.priorities[i][2]<self.priorities[j][2] and time_i<time_j:
                        print("Priority rule for Job%d and Job%d is not fulfilled, time difference: %d"%(i,j,time_j-time_i)) 
                        time_differences+=abs(time_i-time_j)
            print("The sum of time differences according to priority: %d"%(time_differences))"""
        return value,workload_difference,workload_balance
    def check_constraint_single_workload(self,solution):
        """Only for single workload objective,check if the solution fulfills the assconstraint"""
        plan={}
        check_constraint=True
        for i in self.new_tasks.keys():#all the jobs 
            plan[i]={}
            for o_i_name in self.new_tasks[i]:#all operations from the job i of current loop
                j=int(o_i_name.replace("Operation",""))#operation number 
                check_once=0
                if len(self.machine_in_operation[i,j])==1:
                    check_once+=1
                    plan[i][j]=self.machine_in_operation[i,j][0]
                else:
                    for m in self.machine_in_operation[i,j]:#for the machines of the operation j                                                               
                        if ("x%s_%s_%s"%(str(i),str(j),str(m)),1) in solution:#the operation starts on the machine m                             
                            check_once+=1
                            plan[i][j]=m
                if check_once!=1:
                    check_constraint=False
                    print("Constraint assignment is not fulfilled.") 
        return check_constraint
    def check_solution_single_workload(self,solution,objective):
        plan={}
        for i in self.jobs.keys():#all the jobs 
            plan[i]={}
            for o_i_name in self.jobs[i]['task'].keys():#all operations from the job i of current loop
                j=int(o_i_name.replace("Operation",""))#operation number 
                check_once=0
                if len(self.machine_in_operation[i,j])==1:
                    check_once+=1
                    plan[i][j]=self.machine_in_operation[i,j][0]
                else:
                    for m in self.machine_in_operation[i,j]:#for the machines of the operation j                                                               
                        if ("x%s_%s_%s"%(str(i),str(j),str(m)),1) in solution:#the operation starts on the machine m                             
                            check_once+=1
                            plan[i][j]=m
                if check_once!=1:
                    print("Constraint assignment is not fulfilled.")
        workload_machine={}
        for m in range(1,self.number_machines+1):
            if m in list(int(machine_number) for i in self.tasks for j in range(1,len(self.tasks[i])+1) for machine_number in self.machine_in_operation[i,j] ): #if all the operations can not be assigned to the machine, the workload of this machine should not be considered.       
                workload_machine[m]=0
        if objective=="single_workload_minimization":
            for i in plan.keys():
                for j in plan[i]:
                    workload_machine[plan[i][j]]+=self.processingtimes[i,j,plan[i][j]]                    
            minimal_workload=sum(min(self.list_processingtimes[i,int(j.replace("Operation",""))]) for i in self.jobs.keys() for j in self.jobs[i]['task'])
            workload_difference=sum(workload_machine[m] for m in self.workload_machine.keys())-minimal_workload  
            print("The difference of workload between the solution and the minimal workload is: "+str(workload_difference))
            value=workload_difference
        elif objective=="single_workload_balancing":
            for i in plan.keys():
                for j in plan[i]:
                    workload_machine[plan[i][j]]+=self.processingtimes[i,j,plan[i][j]]  
            average_workload=sum(workload_machine[m] for m in self.workload_machine.keys())/len(self.workload_machine.keys())
            workload_balance=sum((workload_machine[m]-average_workload)**2 for m in self.workload_machine.keys())**0.5            
            print("The workload balance is: "+str(workload_balance))
            value=workload_balance
        return value
    def read_excel(self,name):
        """find the points for the Pareto plot
        name: the name of job.txt"""
        solutions_optimal_makespan={}#makespan,priority,workload_balance,workload_minimization
        solutions_optimal_priority={}#makespan,priority
        solutions_optimal_workload_balance={}#makespan,workload
        solutions_optimal_workload_minimization={}#makespan,workload
        excel_folder=load_workbook(filename="Result_new.xlsx")
        write_folder=excel_folder.worksheets[0]
        cells=list(write_folder.iter_rows())[0]
        excel_label=list(cell.value for cell in cells)
        point_priority={}
        point_makespan={}
        for i in write_folder["C"]:
            if i.value=="makespan with priority as constraint":
                row=i.row
                column_makespan=excel_label.index("Makespan")+1
                column_priority=excel_label.index("Priority analysis")+1
                column_workload_balance=excel_label.index("workload balance")+1
                column_workload_minimization=excel_label.index("The difference of workload")+1
                if write_folder.cell(row=row,column=1).value=="MK"+name:
                    if write_folder.cell(row=row,column=column_priority).value in point_priority.keys():
                        if point_priority[write_folder.cell(row=row,column=column_priority).value]["Makespan"]<write_folder.cell(row=row,column=column_makespan).value:
                            break
                    point_priority[write_folder.cell(row=row,column=column_priority).value]={"Priority analysis":write_folder.cell(row=row,column=column_priority).value,"Makespan":write_folder.cell(row=row,column=column_makespan).value,"workload balance":write_folder.cell(row=row,column=column_workload_balance).value,"The difference of workload":write_folder.cell(row=row,column=column_workload_minimization).value}
            if i.value=="makespan":
                row=i.row
                column_makespan=excel_label.index("Makespan")+1
                column_priority=excel_label.index("Priority analysis")+1
                column_workload_balance=excel_label.index("workload balance")+1
                column_workload_minimization=excel_label.index("The difference of workload")+1
                if write_folder.cell(row=row,column=1).value=="MK"+name:
                    point_makespan[write_folder.cell(row=row,column=column_makespan).value]={"Priority analysis":write_folder.cell(row=row,column=column_priority).value,"Makespan":write_folder.cell(row=row,column=column_makespan).value,"workload balance":write_folder.cell(row=row,column=column_workload_balance).value,"The difference of workload":write_folder.cell(row=row,column=column_workload_minimization).value}
        solutions_optimal_priority["MK"+name]=point_priority[min(point_priority.keys())]
        solutions_optimal_makespan["MK"+name]=point_makespan[min(point_makespan.keys())]
        return solutions_optimal_priority,solutions_optimal_makespan
       
if __name__ == "__main__": 
    programm_start=datetime.datetime.now()
    print("The start time of programm: "+str(datetime.datetime.now()))
    list_name=['01','02','03','04','05','06','07','08','09','10']#Name of the job txt
    excel_label=["Problem size","With unavailabilities?","Objective","Procedure Constraint","Processing Constraint","Overlapping Constraint","Assignment Constraint only for single workload","Weight for objective(makespan/on_time)","Weight for workload objective","Weight for priority","workload balance","The difference of workload","Sum of tardiness","On time?","Priority analysis","Priority?","Makespan","the total computation time","Annealing-time(ms)","Solver	Operations number in loop",	"Jobs number in loop",	"num_reads",	"Convergence",	"Iteration","T_max","Extended max finished time",	"Solution"]
    solutions_optimal_makespan={}#makespan,workload
    solutions_optimal_priority={}#makespan,priority
    solutions_optimal_workload_balance={}#makespan,workload
    solutions_optimal_workload_minimization={}#makespan,workload
    for i in list_name:
        solutions_optimal_makespan[i]=[]#makespan,workload
        solutions_optimal_priority[i]=[]#makespan,priority
        solutions_optimal_workload_balance[i]=[]#makespan,workload
        solutions_optimal_workload_minimization[i]=[]#makespan,workload
    solutions_optimal_makespan['01']=[]#makespan,workload
    solutions_optimal_priority['01']=[]#makespan,priority
    solutions_optimal_workload_balance['01']=[]#makespan,workload
    solutions_optimal_workload_minimization['01']=[]#makespan,workload
    KerberosSampler=KerberosSampler()
    """Set the parameters and weights"""
    solver_name="Kerberos"#Now only Kerberos "Kerberos","Kerberos with reverse annealing","classic solver","classic solver"
    objective="makespan"#"single_workload_minimization",,"single_workload_balancing";"makespan";"makespan_with_priority";"on_time";"on_time_priority";"makespan_with_workload_minimization";"makespan_with_workload_balancing"
    name='04' #the name of the txt
    unavailabilities=True #True=unavailabilities are considered;it is not required for the single workload
    T_max=30#maximal completion time in each loop
    extended_max_finish_time=0# for the situation that the defined max finish time of the operation(Priority[1]) is too small,ther is no possible time for the operation
    jobs_number_in_loop=5#the number of jobs in each loop; it is not required for the single workload objective
    operation_number_in_loop=2#the number of operation for each job in each loop; For the single workload objective,it is better to set large numbers
    max_iter=2#max iteration;parameters for the kerberos solver
    convergence=2#max convergence;parameters for the kerberos solver
    num_reads=200 #stands for the number of reads in the solver: if a high value is choosen the solution will be better
    """Constraint-setting: For the objective: makespan,on_time,on_time_priority,makespan_with_workload balancing,on_time_with_workload_balancing"""    
    weight_procedure_constraint=255 # the weight for the procedure constraint
    weight_processing_constraint=255# the weight for the processing constraint
    weight_overlapping_constraint=255 # the weight for the overlapping constraint
    """Objective-setting:For the objective: makespan,on_time"""
    weight_objective=1#the weight for the objective
    """Objective-setting:For the objective:makespan_with_workload balancing,on_time_with_workload_balancing,makespan_with_workload_minimization,on_time_with_workload_minimization"""
    weight_objective_workload=0.5 # the weight for the workload objective 
    weight_objective_makespan=0.5 # the weight for the makespan objective 
    weight_objective_on_time=0.5 # the weight for the on_time objective 
    """Objective-setting:For the objective: makespan_with_priority,on_time_priority"""
    weight_makespan=10# the weight for the makespan objective 
    weight_priority=3# the weight for the priority objective 
    weight_on_time=2# the weight for the on_time objective 
    """Constraint and Objective settings: For the objective: single_workload_balancing,single_workload_minimization"""
    weight_assignment_constraint=500# the weight for the assignment constraint
    weight_objective_workload_single=100# the weight for the objective     
    """------------------------------------------------------------------------------------------------"""
    solution=[]#Empty solution for first loop
    solution_single_workload=[]#optimal solution from single workload objective
    priority_analysis=0
    solution_optimal_makespan=solutions_optimal_makespan[name]#makespan,workload
    solution_optimal_priority=solutions_optimal_priority[name]#makespan,priority
    solution_optimal_workload_balance=solutions_optimal_workload_balance[name]#makespan,workload
    solution_optimal_workload_minimization=solutions_optimal_workload_minimization[name]#makespan,workload
    if objective=="makespan":
        on_time=False#if objective is on time:true
        priority_change=False#if priority should be changed by the current time: true
        priority=False#if considering priority:true
        workload_single=False #considering only workload as objective
        workload_balancing=False#considering workload balance as objective
        workload_minimization=False#considering workload minimization as objective
        with_workload=False#considering workload or not
        data=["MK"+name,unavailabilities,objective,weight_procedure_constraint,weight_objective_makespan,weight_objective_on_time,weight_objective]
    elif objective=="makespan_with_priority":
        on_time=False#if objective is on time:true
        priority_change=False#if priority should be changed by the current time: true
        priority=True#if considering priority:true
        workload_single=False #considering only workload as objective
        workload_balancing=False#considering workload balance as objective
        workload_minimization=False#considering workload minimization as objective
        with_workload=False#considering workload or not
    elif objective=="on_time":
        on_time=True#if objective is on time:true
        priority_change=False#if priority should be changed by the current time: true
        priority=False#if considering priority:true
        workload_single=False #considering only workload as objective
        workload_balancing=False#considering workload balance as objective
        workload_minimization=False#considering workload minimization as objective
        with_workload=False#considering workload or not
    elif objective=="on_time_with_priority":
        on_time=True#if objective is on time:true
        priority_change=False#if priority should be changed by the current time: true
        priority=True#if considering priority:true
        workload_single=False #considering only workload as objective
        workload_balancing=False#considering workload balance as objective
        workload_minimization=False#considering workload minimization as objective
        with_workload=False#considering workload or not
    elif objective=="single_workload_balancing":
        on_time=False#if objective is on time:true
        priority_change=False#if priority should be changed by the current time: true
        priority=False#if considering priority:true
        workload_single=True #considering only workload as objective
    elif objective=="single_workload_minimization":
        on_time=False#if objective is on time:true
        priority_change=False#if priority should be changed by the current time: true
        priority=False#if considering priority:true
        workload_single=True #considering only workload as objective
        with_workload=False
    elif objective=="makespan_with_workload_balancing":
        on_time=False#if objective is on time:true
        priority_change=False#if priority should be changed by the current time: true
        priority=False#if considering priority:true
        workload_single=False #considering only workload as objective
        workload_balancing=True#considering workload balance as objective
        workload_minimization=False#considering workload minimization as objective
        with_workload=True#considering workload or not
    elif objective=="makespan_with_workload_minimization":
        on_time=False#if objective is on time:true
        priority_change=False#if priority should be changed by the current time: true
        priority=False#if considering priority:true
        workload_single=False #considering only workload as objective
        workload_balancing=False#considering workload balance as objective
        workload_minimization=True#considering workload minimization as objective
        with_workload=True#considering workload or not
    elif objective=="on_time_with_workload_balancing":
        on_time=True#if objective is on time:true
        priority_change=False#if priority should be changed by the current time: true
        priority=False#if considering priority:true
        workload_single=False #considering only workload as objective
        workload_balancing=True#considering workload balance as objective
        workload_minimization=False#considering workload minimization as objective
        with_workload=True#considering workload or not
    elif objective=="on_time_with_workload_minimization":
        on_time=True#if objective is on time:true
        priority_change=False#if priority should be changed by the current time: true
        priority=False#if considering priority:true
        workload_single=False #considering only workload as objective
        workload_balancing=False#considering workload balance as objective
        workload_minimization=True#considering workload minimization as objective
        with_workload=True#considering workload or not
    number_loop=0#the number of current loop,for first loop : 0    
    variables=Define_variables(T_max,jobs_number_in_loop,operation_number_in_loop,solution,name,extended_max_finish_time)
    variables.update_jobs(unavailabilities,solution_single_workload)
    variables.update_unavailabilities(unavailabilities)
    sum_solution=[]#all the solutions for all the loops
    sampler=DWaveSampler()#sample using dwavesampler
    #sampler=EmbeddingComposite(DWaveSampler())
    qpu_access_times=0#initialization
    if workload_single:#for single workload objective
        while(variables.new_tasks!={} or solution==[]):        #until all the jobs are finished or one constraint is not fulfilled
            variables.machine_bottleneck_workload_single(sum_solution)
            variables.define_variable_workload_single()
            remaining_tasks=variables.remaining_tasks
            if variables.new_tasks=={}:#all the jobs are finished
                break
            bqm=BQM(variables,KerberosSampler)
            bqm.define_bqm()
            bqm.constraint_assignment_workload_single(weight_assignment_constraint) #weight for the constraint assignment workload
            if objective=="single_workload_minimization":
                bqm.single_objective_workload_minimization(weight_objective_workload_single)#100
            if objective=="single_workload_balancing":
                bqm.single_objective_workload_balancing(weight_objective_workload_single)
            model_input_time=datetime.datetime.now()#the time of inout to QA
            if solver_name=="Kerberos":
                solution,qpu_access_time=bqm.call_bqm_solver_Kerberos(max_iter,convergence,num_reads,sampler)                
            elif solver_name=="Kerberos with reverse annealing":
                solution,qpu_access_time=bqm.call_bqm_solver_Kerberos_with_reverse_annealing(max_iter,convergence,num_reads,sampler)#max_iter,convergence
            elif solver_name=="classic solver":
                solution=bqm.call_bqm_solver_classic()
            qpu_access_times+=qpu_access_time
            solution_obtained_time=datetime.datetime.now()#the time of output of solution
            if number_loop==0:
                time_difference=solution_obtained_time-model_input_time#calulate the time between the input to the QA and the output of solution
            else:
                time_difference+=solution_obtained_time-model_input_time#add all the time differences for all the loops
            sum_solution.extend(solution)
            print(sum_solution)
            print("Solution is obtained"+str(datetime.datetime.now()))
            check_constraint=bqm.check_constraint_single_workload(sum_solution)
            if check_constraint==False: #If one constraint is not fulfilled, the loop is break out.
                break
            gant=plot_workload(sum_solution,variables,number_loop,name,objective)            
            gant.plot_solution(unavailabilities,remaining_tasks,operation_number_in_loop)
            number_loop+=1
        gant.generate_gif(number_loop,unavailabilities)
        value=bqm.check_solution_single_workload(sum_solution, objective)
        print("The end time of programm: "+str(datetime.datetime.now()))
        programm_end=datetime.datetime.now()
        print("Total run time: "+str(programm_end-programm_start))
        print("The computation time: "+str(time_difference))
        print("QPU_access_time: "+str(qpu_access_times)+"ms")
        if check_constraint==True:#store the related infomation in the excel
            excel_folder=load_workbook(filename="Result_new.xlsx")
            write_folder=excel_folder.worksheets[0]
            for i in  range(1,1000):
                if write_folder.cell(row=i,column=1).value==None:#write the information in the blank row
                    #for j in range(1,1000):
                        #if "Problemsize" not in (write_folder.cell(row=1,column=k).value for k in range(1,1000) ):
                            #write_folder.cell(row=1,column=1,value="Problemsize")
                       # if "With_unavaliability" not in (write_folder.cell(row=1,column=j).value for k in range(1,1000) ):
                            #write_folder.cell(row=1,column=2,value="With_unavaliability")
                        #if write_folder.cell(row=1,column=j).value=="problemsize":
                            #write_folder.cell(row=i,column=j,value="MK"+str(name))
                        #if write_folder.cell(row=1,column=j)
                    write_folder["A"+str(i)]="MK"+str(name)
                    write_folder["B"+str(i)]="yes"
                    write_folder["C"+str(i)]=objective                
                    write_folder["G"+str(i)]=weight_assignment_constraint
                    write_folder["I"+str(i)]=weight_objective_workload_single
                    if objective=="single_workload_balancing":
                        write_folder["K"+str(i)]=value
                    elif objective=="single_workload_minimization":
                        write_folder["L"+str(i)]=value
                    write_folder["R"+str(i)]=time_difference
                    write_folder["S"+str(i)]=qpu_access_times
                    write_folder["T"+str(i)]=solver_name
                    write_folder["U"+str(i)]=operation_number_in_loop
                    write_folder["W"+str(i)]=num_reads
                    write_folder["X"+str(i)]=convergence
                    write_folder["Y"+str(i)]=max_iter
                    write_folder["AB"+str(i)]=str(sum_solution)                                                
                    break
            excel_folder.save("Result_new.xlsx")        
    else:
        while(variables.new_tasks!={} or solution==[]):        #until all the jobs are finished or one constraint is not fulfilled
            variables.define_bottleneck_factor(sum_solution,priority,priority_change,0,on_time,with_workload)#solution,with_priority,priority_change,current_time,on_time
            variables.define_variables(on_time,number_loop)
            remaining_tasks=variables.remaining_tasks
            if variables.new_tasks=={}:#all the jobs are finished
                break
            bqm=BQM(variables,KerberosSampler)
            bqm.define_bqm()
            bqm.constraint_procedure(weight_procedure_constraint)#weight for the procedure constraint
            bqm.constraint_processing(weight_processing_constraint)#weight for the processing constraint
            bqm.constraint_overlapping(weight_overlapping_constraint)#weight for the overlapping constraint
            if objective=="makespan":
                bqm.objective_makespan(weight_objective,number_loop)#weight for the makespan objective
            elif objective=="makespan_with_priority":
                bqm.objective_priority_makespan(weight_makespan,weight_priority,0,False)#weight for the priority_on_time,current time, priority_change
            elif objective=="on_time":
                bqm.objective_on_time(weight_objective,number_loop)#weight for the on time objective
            elif objective=="on_time_with_priority":
                bqm.objective_priority_on_time(weight_on_time,0,False)#weight for the priority_on_time,current time, priority_change 
            elif objective=="makespan_with_workload_balancing":
                bqm.objective_makespan(weight_objective_makespan,number_loop)#weight for the makespan objective
                bqm.objective_workload_balancing(weight_objective_workload)#weight for the balance objective
            elif objective=="on_time_with_workload_balancing":
                bqm.objective_on_time(weight_objective_on_time,number_loop)#weight for the makespan objective
                bqm.objective_workload_balancing(weight_objective_workload)#weight for the balance objective
            elif objective=="makespan_with_workload_minimization":
                bqm.objective_makespan(weight_objective_makespan,number_loop)#weight for the makespan objective
                bqm.objective_workload_balancing(weight_objective_workload)#weight for the balance objective
            elif objective=="on_time_with_workload_minimization":
                bqm.objective_makespan(weight_objective_on_time,number_loop)#weight for the makespan objective
                bqm.objective_workload_balancing(weight_objective_workload)#weight for the balance objective
            #sampler=EmbeddingComposite(DWaveSampler())
            model_input_time=datetime.datetime.now()#the time of inout to QA
            if solver_name=="Kerberos":
                solution,qpu_access_time=bqm.call_bqm_solver_Kerberos(max_iter,convergence,num_reads,sampler)                
            elif solver_name=="Kerberos with reverse annealing":
                solution,qpu_access_time=bqm.call_bqm_solver_Kerberos_with_reverse_annealing(max_iter,convergence,num_reads,sampler)#max_iter,convergence
            elif solver_name=="classic solver":
                solution=bqm.call_bqm_solver_classic()
            qpu_access_times+=qpu_access_time
            solution_obtained_time=datetime.datetime.now()#the time of output of solution
            if number_loop==0:
                time_difference=solution_obtained_time-model_input_time#calulate the time between the input to the QA and the output of solution
            else:
                time_difference+=solution_obtained_time-model_input_time#add all the time differences for all the loops
            sum_solution.extend(solution)
            print(sum_solution)
            print("Solution is obtained"+str(datetime.datetime.now()))
            gant=plot(sum_solution,variables,number_loop,name,objective)
            gant.plot_solution(unavailabilities,jobs_number_in_loop,operation_number_in_loop,remaining_tasks)
            check_constraint=bqm.check_constraint(sum_solution,priority)[0]               
            priority_analysis+=bqm.check_constraint(sum_solution,priority)[1]
            if check_constraint==False: #If one constraint is not fulfilled, the loop is break out.
                break        
            number_loop+=1
        gant.generate_gif(number_loop,unavailabilities)
        value,workload_difference,workload_balance=bqm.check_solution(sum_solution,on_time,priority,workload_balancing,workload_minimization,solution_optimal_makespan,solution_optimal_priority,solution_optimal_workload_balance,solution_optimal_workload_minimization)
        print("The result of the priority analysis is "+ str(priority_analysis))
        print("The end time of programm: "+str(datetime.datetime.now()))
        programm_end=datetime.datetime.now()
        print("Total run time:"+str(programm_end-programm_start))
        #print("The computation time:"+str(time_difference))
        print("QPU_access_time:"+str(qpu_access_times)+"ms")
        #if objective== "makespan" or objective=="on_time":
            #data_list=
            #for i in label:     
        if check_constraint==True:
            excel_folder=load_workbook(filename="Result_new.xlsx")
            write_folder=excel_folder.worksheets[0]
            for i in  range(1,1000):#write the information in the blank row
                if write_folder.cell(row=i,column=1).value==None:
                    write_folder["A"+str(i)]="MK"+str(name)
                    write_folder["B"+str(i)]="yes"
                    write_folder["C"+str(i)]=objective                
                    write_folder["D"+str(i)]=weight_procedure_constraint
                    write_folder["E"+str(i)]=weight_processing_constraint
                    write_folder["F"+str(i)]=weight_overlapping_constraint
                    if objective== "makespan" or objective=="on_time":
                        write_folder["H"+str(i)]=weight_objective
                        if objective=="makespan":
                            write_folder["Q"+str(i)]=value
                        else:
                            write_folder["M"+str(i)]=value
                        write_folder["K"+str(i)]=workload_balance
                        write_folder["L"+str(i)]=workload_difference
                        write_folder["O"+str(i)]=priority_analysis
                    elif objective=="makespan_with_workload balancing" or objective=="on_time_with_workload_balancing":
                        if objective=="makespan_with_workload balancing":
                            write_folder["H"+str(i)]=weight_objective_makespan
                            write_folder["Q"+str(i)]=value
                        elif objective=="on_time_with_workload_balancing":
                            write_folder["H"+str(i)]=weight_objective_on_time
                            write_folder["M"+str(i)]=value
                            if value==0:
                                write_folder["N"+str(i)]="yes"
                            else:
                                write_folder["N"+str(i)]="no"
                        write_folder["I"+str(i)]=weight_objective_workload
                        write_folder["K"+str(i)]=workload_balance
                        write_folder["L"+str(i)]=workload_difference
                        write_folder["O"+str(i)]=priority_analysis
                    elif objective=="makespan_with_priority" or objective=="on_time_priority":
                        if objective=="makespan_with_priority":
                            write_folder["H"+str(i)]=weight_makespan
                            write_folder["Q"+str(i)]=value
                        else:
                            write_folder["H"+str(i)]=weight_on_time
                            write_folder["M"+str(i)]=value
                            if value==0:
                                write_folder["N"+str(i)]="yes"
                            else:
                                write_folder["N"+str(i)]="no"
                        write_folder["J"+str(i)]=weight_priority
                        write_folder["O"+str(i)]=priority_analysis
                        write_folder["K"+str(i)]=workload_balance
                        write_folder["L"+str(i)]=workload_difference
                        if priority_analysis==0:
                            write_folder["P"+str(i)]="yes"
                        else:
                            write_folder["P"+str(i)]="no"
                    write_folder["R"+str(i)]=time_difference
                    write_folder["S"+str(i)]=qpu_access_times
                    write_folder["T"+str(i)]=solver_name
                    write_folder["Z"+str(i)]=T_max
                    write_folder["U"+str(i)]=operation_number_in_loop
                    write_folder["V"+str(i)]=jobs_number_in_loop
                    write_folder["W"+str(i)]=num_reads
                    write_folder["X"+str(i)]=convergence
                    write_folder["Y"+str(i)]=max_iter
                    write_folder["AA"+str(i)]=extended_max_finish_time
                    write_folder["AB"+str(i)]=str(sum_solution)                                                      
                    break
            excel_folder.save("Result_new.xlsx")
    
        
        
            
    
    
        