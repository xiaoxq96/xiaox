# -*- coding: utf-8 -*-
"""
Created on Fri Oct 21 17:22:21 2022

@author: Xiaox
"""

import argparse
from itertools import combinations, permutations
import numpy as np
from typing import Tuple
import re
import matplotlib.pyplot as plt
import matplotlib.patches as mpatch

from unilts import read_instance

class zweiD_Problem():
    def __init__(self,data = read_instance()):
        self.stueck_ids = np.repeat(data["stueck_ids"], data["quantity"])
        self.num_stueck = np.sum(data["quantity"], dtype=np.int32)
        self.stueck_lange = np.repeat(data["stueck_lange"], data["quantity"])
        self.stueck_breite = np.repeat(data["stueck_breite"], data["quantity"])
        print(f'Anzahl der Stücke: {self.num_stueck}')
        self.platte_lange = data["platte_dim"][0]
        self.platte_breite = data["platte_dim"][1]
        self.num_platte = data["num_platte"]
        self.gesamte_platte_lange=self.platte_lange*self.num_platte
        self.lowest_num_platte = np.ceil(
            np.sum(self.stueck_lange*self.stueck_breite) / (
                    self.platte_lange*self.platte_breite))
        if self.lowest_num_platte > self.num_platte:
            raise RuntimeError(
                f'anzahl der Platten ist im mindesten {self.lowest_num_platte}'+
                    'try increasing the number of platte'
            )
        print(f'anzahl der Platten ist im mindesten:{self.lowest_num_platte}')
        
        
        
        self.X_i={}
        
        
    def define_variables(self):
        #self.P_j={(j):'s_{}'.format(j)for j in range(self.num_platte)}
        self.X_i={(i,j,r,a,b):'x_{}_{}_{}_{}_{}'.format(i,j,r,a,b)for i in range(self.num_stueck)
                   for j in range(self.num_platte)
                   for r in range(2) #0:nicht umgedrehnt 1:umgedrehnt
                   for a in range(j*self.platte_lange,(j+1)*self.platte_lange-self.eff_dim[i][r][0]+1)
                   for b in range(self.platte_breite - self.eff_dim[i][r][1]+1)}
        self.variables=[self.X_i]
        return self.variables
    
    
    
    def effective_dim(self):
        self.eff_dim={}
        for i in range(self.num_stueck):
            self.eff_dim[i]={}
            p1=list(permutations([self.stueck_lange[(i)],self.stueck_breite[(i)]]))
            self.eff_dim[i][0]=p1[(0)]
            self.eff_dim[i][1]=p1[(1)]
        return [self.eff_dim]

    def zeichnung(self):
            self.solution={'x_0_0_1_2_0': 1, 'x_1_0_1_5_0': 1, 'x_2_0_1_8_2': 1, 'x_3_1_1_10_0': 1, 'x_4_2_1_22_1': 1, 'x_5_1_1_12_0': 1}
            self.eff_daten=list(key for key in self.solution.keys() if key in self.X_i.values())
            print(self.eff_daten)
            self.ids=[]
            self.i_loc=[]
            self.um=[]
            self.x_achse=[]
            self.y_achse=[]
            for n in self.eff_daten:
                    zahlen=re.findall(r"\d+",n)
                    ids_pos= list(map(int,zahlen))
                    self.ids.append(ids_pos[(0)])
                    self.i_loc.append(ids_pos[(1)])
                    self.um.append(ids_pos[(2)])
                    self.x_achse.append(ids_pos[(3)])
                    self.y_achse.append(ids_pos[(4)])
            print(self.ids)
            print(self.i_loc)
            print(self.um)
            print(self.x_achse)
            print(self.y_achse)
    
    
            fig = plt.figure()
            ax = fig.add_subplot()
            n=self.num_stueck
            colors=plt.cm.jet(np.linspace(0, 1, n))
            for x,y,i,r,j,c in zip(self.x_achse,self.y_achse,self.ids,self.um,self.i_loc,colors):
                    txt=str(i)
                    plt.text(x+0.5,y+0.5,txt,fontsize=7)
                    rect=mpatch.Rectangle((x,y),self.eff_dim[i][r][0],self.eff_dim[i][r][1],edgecolor = 'green',facecolor = c,fill=True,alpha=0.3)
                    ax.add_patch(rect)
            
            ticks=[]
            labels=[]
            for j in range(self.num_platte):
                plt.axvline(x=((j+1)*self.platte_lange), ymax = 0.5 ,ymin=0)
                ticks.append((j+1)*self.platte_lange)
                labels.append('Platte_' + str(j+1))
            plt.xticks(ticks,labels)
            plt.axhline(y=self.platte_breite,xmax=0.5)
            ax.axis([0,2*self.gesamte_platte_lange,0,2*self.platte_breite])
            ax.set_aspect(1)
            plt.show()
        
if __name__== "__main__":
    
    a=zweiD_Problem()
    a.effective_dim()
    
    v=a.define_variables()
    
    
    
    
    a.zeichnung()
