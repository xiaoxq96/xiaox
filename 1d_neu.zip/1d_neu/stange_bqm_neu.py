# -*- coding: utf-8 -*-
"""
Created on Wed Sep 28 17:15:40 2022

@author: Xiaox
"""

import argparse
from dimod import quicksum, BinaryQuadraticModel, Real, Binary, SampleSet
from dwave.system import LeapHybridBQMSampler
from hybrid.reference.kerberos import KerberosSampler
from itertools import combinations, permutations
import numpy as np
from typing import Tuple
import re
import matplotlib.pyplot as plt
import matplotlib.patches as mpatch
from matplotlib.pyplot import MultipleLocator
from dwave.system.samplers import DWaveSampler


from unilts1 import read_instance
#from output import zeichnung


class eindim_Problem():
    def __init__(self,data = read_instance()):
        self.stueck_ids = np.repeat(data["stueck_ids"], data["quantity"])
        self.num_stueck = np.sum(data["quantity"], dtype=np.int32)
        self.stueck_lange = np.repeat(data["stueck_lange"], data["quantity"])
        print(f'Anzahl der Stücke: {self.num_stueck}')
        self.stange_lange = data["stange_lange"]
        self.num_stange = data["num_Stange"]
        print(f'Anzahl der Stange: {self.num_stange}')
        print(f'Länge der Stange: {self.stange_lange}')
        self.gesamte_stange_lange=self.stange_lange*self.num_stange
        self.lowest_num_stange = np.ceil(
            np.sum(self.stueck_lange) / (
                    self.stange_lange))
        if self.lowest_num_stange > self.num_stange:
            raise RuntimeError(
                f'anzahl der stangen ist im mindesten {self.lowest_num_stange}'+
                    'try increasing the number of stange'
            )
        print(f'anzahl der stangen ist im mindesten:{self.lowest_num_stange}')
        
        
        #self.S_j={}
        #self.U_ij={}
        self.X_ija={}
        #self.Q_ik={}
        
    def define_variables(self):
        #self.S_j={(j):'s_{}'.format(j)for j in range(self.num_stange)}
        #S_j没有被用
        self.X_ija={(i,j,a):'x_{}_{}_{}'.format(i,j,a)for i in range(self.num_stueck)
                   for j in range(self.num_stange)
                   for a in range(j*self.stange_lange,(j+1)*self.stange_lange-self.stueck_lange[(i)]+1)}
        #stück_i左端坐标是a
        self.variables=[self.X_ija]
        '''[self.S_j,self.U_ij,self.X_ia,self.Q_ik]'''
        return #self.variables
    
    
    
    def define_bqm(self):
        self.bqm=BinaryQuadraticModel('BINARY')
        
        for i in self.variables:      
            for j in i.values():
                self.bqm.add_variable(j)
        return self.bqm
        
    def grenze_constraint(self,weight):
        #stück_i的左端和右端不能超过所在stange的长度
        for i in range(self.num_stueck):
            for j in range(self.num_stange):
                for a in range(j*self.stueck_lange,(j+1)*self.stange_lange):
                
                        '''
                        if j!= int(a/30):
                            self.bqm.add_quadratic(self.X_ia[(i,a)],self.U_ij[(i,j)],weight)
                            
                        '''
                        if (a+self.stueck_lange[(i)])>((j+1)*self.stange_lange):
                            self.bqm.add_linear(self.X_ia[(i,a)],weight)
                    
        '''
                    so=[(self.U_ij[(i,j)], -self.gesamte_stange_lange)for j in range(self.num_stange)]
                    soj=[(self.U_ij[(i,j)],(j+1)*self.stange_lange)for j in range(self.num_stange)]
                    slen=[(self.X_ia[(i,a)], -(a+self.stueck_lange[i]))for a in range(self.gesamte_stange_lange)]#stueck_linkes_eck_negativ
                    son=[(self.U_ij[(i,j)], -(self.stange_lange*j))for j in range(self.num_stange)]#stueck_on_negativ
                    sle=[(self.X_ia[(i,a)], a)for a in range(self.gesamte_stange_lange)]
                    
                    self.bqm.add_linear_inequality_constraint(so+slen+soj,
                                                              lagrange_multiplier=weight,
                                                              constant=self.gesamte_stange_lange,
                                                              lb=0,
                                                              label='grenze_constraint_1')
                    self.bqm.add_linear_inequality_constraint(son+sle,
                                                              lagrange_multiplier=weight,
                                                              lb=0,
                                                              label='grenze_constraint_2')
            '''
        return
                
                
    def geomerie_constraint(self,weight):
        #stück_i和stück_k不能重叠
        for i, k in combinations(range(self.num_stueck),r=2):
            for j in range(self.num_stange):
                for a in range(j*self.stange_lange,(j+1)*self.stange_lange-self.stueck_lange[(i)]+1):
                    for b in range(j*self.stange_lange,(j+1)*self.stange_lange-self.stueck_lange[(k)]+1):
                        if (a-self.stueck_lange[(k)]) < b < (a+self.stueck_lange[(i)]):
                            self.bqm.add_quadratic(self.X_ija[(i,j,a)],self.X_ija[(k,j,b)],weight)
                        #elif a<b and (b-a)<self.stueck_lange[(i)]:
                            #self.bqm.add_quadratic(self.X_ija[(i,j,a)],self.X_ija[(k,j,b)],weight)
            '''
            slear=[(self.X_ia[(i,a)], -(a+self.stueck_lange[i]))for a in range(self.gesamte_stange_lange+1)]
            slebr=[(self.X_ia[(k,b)], b)for b in range(self.gesamte_stange_lange+1)]
            sleal=[(self.X_ia[(i,a)], a)for a in range(self.gesamte_stange_lange+1)]
            slebl=[(self.X_ia[(k,b)], -(b+self.stueck_lange[k]))for b in range(self.gesamte_stange_lange+1)]
            ikbr=[(self.Q_ik[(i,k)], -self.gesamte_stange_lange)]
            ikbl=[(self.Q_ik[(i,k)],self.gesamte_stange_lange)]
            self.bqm.add_linear_inequality_constraint(slear+slebr+ikbr,
                                                              lagrange_multiplier=weight,
                                                              lb=0,
                                                              constant=self.gesamte_stange_lange,
                                                              label='geometrie_rechts')
            self.bqm.add_linear_inequality_constraint(sleal+slebl+ikbl,
                                                              lagrange_multiplier=weight,
                                                              lb=0,
                                                              label='geometrie_links')
            '''
        return
                    
    def variables_constraints(self,weight):
        for i in range(self.num_stueck):
                '''
                self.bqm.add_linear_equality_constraint([(self.U_ij[(i,j)],1)for j in range(self.num_stange)],
                                                                lagrange_multiplier=weight, 
                                                                constant=-1)
                '''
                self.bqm.add_linear_equality_constraint([(self.X_ija[(i,j,a)],1)for j in range(self.num_stange)
                                                         for a in range(j*self.stange_lange,(j+1)*self.stange_lange-self.stueck_lange[(i)]+1)],
                                                                lagrange_multiplier=weight, 
                                                                constant=-1)
                
                
        return
                        
    def stuecke_position_constraint(self,weight):
        #stück_i只能在已经启用的stang_j上切割
        for i in range(self.num_stueck):
                for a in range(self.gesamte_stange_lange):
                    for j in range(self.num_stange):
                        if j == int(a/30):
                            self.bqm.add_quadratic(self.S_j[(j)],self.X_ia[(i,a)],weight)
        '''
        for j in range(self.num_stange):
            for i in range(self.num_stueck):
                
                self.bqm.add_quadratic(self.S_j[(j)],self.U_ij[(i,j)],-weight)
                self.bqm.add_linear(self.U_ij[(i,j)],weight)
        
        
                
                self.bqm.add_linear_inequality_constraint([(self.S_j[(j)],1),(self.U_ij[(i,j)],-1)],
                                                          lagrange_multiplier=weight,
                                                          lb=0,
                                                          label='geometrie_rechts')
                '''
                
        return
        
    def stange_reihenfolge_constraint(self,weight):
        #stange按顺序被切割
        for j in range(self.num_stange):
            if j ==0:
                self.bqm.add_linear_equality_constraint([(self.S_j[(j)],1)],weight*2,-1)
            else:
                self.bqm.add_linear_inequality_constraint([(self.S_j[(j-1)], 1),(self.S_j[(j)], -1)],
                                                      lagrange_multiplier=weight,
                                                      lb=0,
                                                      label='stangen_reihenfolge')
        
            
        
        return     
                    
    def anzhal_objektive(self,weight):
        #所用最少的stange
        bias={}
        for i in range(self.num_stueck):
            for j in range(self.num_stange):
                for a in range(j*self.stange_lange,(j+1)*self.stange_lange-self.stueck_lange[(i)]+1):
                    bias[self.X_ija[(i,j,a)]]=(a+self.stueck_lange[(i)])*weight
            #self.bqm.add_linear(self.X_ija[i,j,a],a)
            
        self.bqm.add_linear_from(bias)
        return
                
    def reste_objektive(self,weight):
        #所用面积最小
        for j in range(self.num_stange):
            self.bqm.add_linear(self.S_j[(j)],self.stange_lange*weight)
            for i in range(self.num_stueck):
                self.bqm.add_linear(self.U_ij[(i,j)],-self.stueck_lange[i]*weight)
        return
                    
    def call_bqm_solver(self):
        '''
        sampler = LeapHybridBQMSampler(token='EbWg-1dc4f5bb6bc7384895496a5dff589cc676d6e1a9')
        raw_sampleset = sampler.sample(self.bqm,label="Stange_Problem")
        best_sample = raw_sampleset.first.sample
        self.solution={}
        for key in best_sample:
            if best_sample[key] !=0 and "slack" not in key:
                self.solution[key]=best_sample[key]
        return self.solution
        '''
        sampler = KerberosSampler().sample(self.bqm,max_iter=10,convergence=5,qpu_sampler=DWaveSampler(),qpu_params={'label': 'stange_bqm'}, qpu_reads=2500)
        samplerSET=sampler.samples()
        self.solution={}
        for key in samplerSET:
            sampler =key
        for key in sampler:
            if sampler[key] !=0 and "slack" not in key:
                self.solution[key]=sampler[key]
        
        return self.solution
    
    
    def zeichnung(self):
        self.eff_daten=list(key for key in self.solution.keys() if key in self.X_ija.values())
        print(self.eff_daten)
        self.ids=[]
        self.i_loc=[]
        self.x_achse=[]
        for n in self.eff_daten:
            zahlen=re.findall(r"\d+",n)
            ids_x_achse= list(map(int,zahlen))
            self.ids.append(ids_x_achse[0])
            self.i_loc.append(ids_x_achse[1])
            self.x_achse.append(ids_x_achse[2])
        print(self.ids)
        print(self.i_loc)
        print(self.x_achse)


        fig = plt.figure()
        ax = fig.add_subplot()
        x_major_locator = MultipleLocator(1)
        ax.xaxis.set_major_locator(x_major_locator)
        plt.title("1D-CSP")
        ticks=[]
        labels=[]
        for j in range(self.num_stange):
            ticks.append(j)
            labels.append('stang_' + str(j+1))
        plt.yticks(ticks,labels)
        ids = []
        for i in self.stueck_ids:
            if i not in ids:
                ids.append(i)
        #ids=list(set(self.stueck_ids))
        langes=[]
        for i in self.stueck_lange:
            if i not in langes:
                langes.append(i)
        #langes.sort(key=self.stueck_lange.index)
        n=len(ids)
        colors=plt.cm.jet(np.linspace(0, 1, n))
        legend_i=[]
        for i in ids:
            legend_i.append(i)
            legend_i[i] = mpatch.Patch(color=colors[i], label=f'id{i}:{langes[i]} cm',alpha=0.5)
        stange_legend=mpatch.Patch(color="tab:gray", label=f'Stange:{self.stange_lange} cm',alpha=0.3)
        legend_i.append(stange_legend)
        ax.legend(handles=legend_i,bbox_to_anchor=(1,0.8),loc='center left')
        for j in range (self.num_stange):
            rect=mpatch.Rectangle((0,j),self.stange_lange,0.25,color="tab:gray",alpha=0.3)
            ax.add_patch(rect)
        for x,i,j in zip(self.x_achse,self.ids,self.i_loc):
                txt=f"id{self.stueck_ids[(i)]}"+" "+f"Teil {i}"
                plt.text(x % self.stange_lange+0.5,j,txt,fontsize=8)
                rect=mpatch.Rectangle((x % self.stange_lange,j),self.stueck_lange[(i)],0.25,edgecolor = 'green',facecolor =colors[self.stueck_ids[(i)]],fill=True,alpha=0.5)
                ax.add_patch(rect)
        '''
        ticks=[]
        labels=[]
        for j in range(self.num_stange):
            ticks.append(j*self.stange_lange)
            labels.append('stang_' + str(j+1))
        plt.yticks(ticks,labels)
        '''
        ax.axis([0,self.stange_lange,0,self.num_stange])
        plt.show()
        
    def prufung(self):
    
        
            
                    #print(self.bqm.get_linear(self.X_ia[(i,a)]))
                    
                    #for j in range(self.num_stange):
                        #print(self.bqm.get_quadratic(self.X_ia[(1,12)],self.X_ia[(6,28)]))
                        for i in range(1):
                            for j in range(self.num_stange):
                                for a in range(j*self.stange_lange,(j+1)*self.stange_lange-self.stueck_lange[(i)]+1):
                                    print(self.bqm.get_linear(self.X_ija[(i,j,a)]))
                        #print(self.bqm.get_linear(self.S_j[(j)]))
                                    #print(self.bqm.get_quadratic(self.S_j[(j)],self.X_ia[(i,a)]))
        

        
if __name__=="__main__":
    a=eindim_Problem()
    v=a.define_variables()
    bqm=a.define_bqm()
    
    a.variables_constraints(1000)
    
    a.geomerie_constraint(860)
    #a.grenze_constraint(850)
    
    #a.stuecke_position_constraint(850)  
    a.anzhal_objektive(3.22)
    #a.stange_reihenfolge_constraint(700)

    
    #a.prufung() 
    
    
    
    
    
    
    '''
    a.variables_constraints(1200)
    
    a.stange_reihenfolge_constraint(827)
    a.stuecke_position_constraint(331)
    
    a.geomerie_constraint(500)
    a.grenze_constraint(10)
    
    a.anzhal_objektive(200)
    a.reste_objektive(200)
    '''
    
    solution= a.call_bqm_solver()
    print(solution)
    
    a.zeichnung()
    